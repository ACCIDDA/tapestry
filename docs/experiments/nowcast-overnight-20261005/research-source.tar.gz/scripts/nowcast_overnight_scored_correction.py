"""Replay saved nowcasters on unique frozen-Hub origin/location input cells."""
import argparse,json
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from tapestry.dataset import cv
from tapestry.dataset.build import load,covariate_names_for
from tapestry.data.geography import STATE_FIPS
from tapestry.model.scenario import Scenario
from tapestry.experiment.weekend import scheduled_reports
from tapestry.evaluation.totals import frozen_cases
from tapestry.evaluation.hubs import CHANNEL
p=argparse.ArgumentParser();p.add_argument('-e','--experiment',required=True);p.add_argument('--season',default='2025-2026');a=p.parse_args()
root=Path('data/experiments')/a.experiment;settings=json.loads((root/'experiment.json').read_text());panel=load(settings['dataset']);frozen=Path(settings['frozen']);support={}
for case in frozen_cases(frozen):
    if case['season']!=a.season:continue
    u=pd.read_parquet(frozen/case['directory']/'units.parquet')[['reference_date','location']].drop_duplicates()
    support[CHANNEL[case['target']]]={(str(np.datetime64(str(r.reference_date)[:10])-np.timedelta64(7,'D')), 'US' if r.location=='US' else STATE_FIPS[str(r.location).zfill(2)]) for r in u.itertuples()}
rows=[]
for r in pd.read_csv(root/'design.csv').itertuples():
    if r.architecture!='C3' or r.family!='two_stage':continue
    s=Scenario.from_string(r.scenario);truth=cv.fold(panel,s,a.season).score
    raw=[scheduled_reports(e,panel,list(covariate_names_for(s.covariate_set)))[0] for e in truth]
    for path in (root/r.run_id).glob(f's*/attempt-*/eval_{a.season}/nowcast_correctors.pt'):
        model=torch.load(path,map_location='cpu',weights_only=False)['final']
        corrected=model.apply_batch(raw) if hasattr(model,'apply_batch') else [model.apply(e) for e in raw]
        for k,valid in support.items():
            for geo in ['states_dc','US']:
                before=[];after=[]
                for t,x,z in zip(truth,raw,corrected):
                    for li,loc in enumerate(t['locations']):
                        if (loc=='US')!=(geo=='US') or (t['context_dates'][-1],loc) not in valid:continue
                        if not (t['available'][-1,k,li] and x['available'][-1,k,li]):continue
                        before.append(abs(x['values'][-1,k,li]-t['values'][-1,k,li]));after.append(abs(z['values'][-1,k,li]-t['values'][-1,k,li]))
                if before:rows.append(dict(architecture=r.architecture,treatment=r.treatment,seed=int(path.parents[2].name[1:]),season=a.season,target=panel['target_names'][k],geography=geo,cells=len(before),raw_mae=float(np.mean(before)),corrected_mae=float(np.mean(after)),scope='Unique own-target frozen-Hub origin/location input cells; latest week only; not WIS weighted; final proxies included',training_seasons='2022-2023,2023-2024,'+('2024-2025' if a.season=='2025-2026' else '2025-2026'),reporting_error_source='2024-2025' if a.season=='2025-2026' else '2025-2026'))
q=pd.DataFrame(rows).drop_duplicates(['architecture','treatment','seed','season','target','geography'],keep='last');out=Path('docs/experiments/nowcast-overnight-20261005');q.to_csv(out/f'frozen-support-nowcaster-correction-{a.season}.csv',index=False)
print(q[q.geography.eq('states_dc')][['treatment','target','cells','raw_mae','corrected_mae']].to_string(index=False))
