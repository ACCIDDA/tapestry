"""Focused B2 C1/C2/C3 joint-loss repair and trajectory-nowcast experiments."""
import argparse,json,subprocess,sys
from dataclasses import replace
from pathlib import Path
import pandas as pd
from tapestry.model.scenario import Scenario
p=argparse.ArgumentParser();p.add_argument('-e','--experiment',required=True);p.add_argument('--seeds',nargs='+',default=['42']);a=p.parse_args()
r=pd.read_csv('docs/experiments/b-2-t0/named_ranking.csv').head(3)
rows=[]
for row in r.itertuples():
    b=replace(Scenario.from_string(row.config_id),supplied_final=False,mask_rate=0.,reporting_missingness=False,reporting_augmentation='vintage')
    arms=[('Direct forecast; unchanged finalized training inputs',dict(weekend_family='direct',reporting_probability=0.)),('Direct forecast; half-strength local reporting errors',dict(weekend_family='direct',reporting_strength=.5)),('Direct forecast; full-strength local reporting errors',dict(weekend_family='direct'))]
    for weight in (.05,.25,1.):
        arms.append((f'Joint recent/future labels; auxiliary weight {weight}; full errors',dict(weekend_family='joint',joint_weight=weight,nowcast_weeks=4)))
    for name,kw in arms:
        s=replace(b,**kw);rows.append(dict(architecture=row.label,treatment=name,family=s.weekend_family,scenario=s.scenario_string,run_id=s.run_id))
folder=Path('data/experiments')/a.experiment
settings=json.loads(Path('data/experiments/b-2-t0/experiment.json').read_text())
cmd=[sys.executable,'-m','tapestry.experiment.planner','plan','-e',a.experiment,'-s',*[x['scenario'] for x in rows],'--seeds',*a.seeds,'--device','cuda','--eval-members','256','--dataset',settings['dataset'],'--frozen',settings['frozen']]
subprocess.run(cmd,check=True)
# Final comparisons always retain three-seed controls; other recipes start as pilots.
controls=[x['scenario'] for x in rows if 'unchanged finalized training inputs' in x['treatment']]
control_cmd=[sys.executable,'-m','tapestry.experiment.planner','plan','-e',a.experiment,'-s',*controls,'--seeds','42','43','44','--device','cuda','--eval-members','256','--dataset',settings['dataset'],'--frozen',settings['frozen']]
subprocess.run(control_cmd,check=True)
print(' '.join(control_cmd))
pd.DataFrame(rows).to_csv(folder/'design.csv',index=False)
print(' '.join(cmd))
