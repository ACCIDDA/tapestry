"""Two-by-two donor-pair supervision and correction-strength comparison on C1."""
import argparse,json,subprocess,sys
from pathlib import Path
from dataclasses import replace
import pandas as pd
from tapestry.model.scenario import Scenario
p=argparse.ArgumentParser();p.add_argument('-e','--experiment',required=True);p.add_argument('--seeds',nargs='+',default=['42','43','44']);a=p.parse_args()
source=Path('data/experiments/nowcast-overnight-c1-correction-confirm-20261005');design=pd.read_csv(source/'design.csv');settings=json.loads((source/'experiment.json').read_text())
base=Scenario.from_string(design[design.treatment.str.contains('nowcaster refitted per seed')].iloc[0].scenario)
raw=Scenario.from_string(design[design.treatment.str.contains('CPU replay control')].iloc[0].scenario)
rows=[]
for observed in [False,True]:
    for strength in [1.,.5]:
        s=replace(base,correction_observed_pairs_only=observed,correction_strength=strength)
        treatment=f'Existing clean-input C1; nonlinear nowcaster refitted per seed; '+('observed donor pairs only' if observed else 'include zero-error fallback cells')+f'; correction strength {strength:g}'
        rows.append(dict(architecture='C1',treatment=treatment,family='fixed_corrected',scenario=s.scenario_string,run_id=s.run_id))
rows.append(dict(architecture='C1',treatment='Existing clean-input forecaster; raw archived evaluation inputs; CPU replay control',family='fixed_corrected',scenario=raw.scenario_string,run_id=raw.run_id))
cmd=[sys.executable,'-m','tapestry.experiment.planner','plan','-e',a.experiment,'-s',*[r['scenario'] for r in rows],'--seeds',*a.seeds,'--device','cpu','--eval-members','256','--dataset',settings['dataset'],'--frozen',settings['frozen']]
subprocess.run(cmd,check=True);pd.DataFrame(rows).to_csv(Path('data/experiments')/a.experiment/'design.csv',index=False)
print(' '.join(cmd))
