"""Fixed-forecaster input replay, paired only against the CPU raw-input replay."""
import argparse
from pathlib import Path
import pandas as pd
from tapestry.experiment.planner import rank
from tapestry.model.scenario import Scenario
p=argparse.ArgumentParser();p.add_argument('-e','--experiments',nargs='+',required=True);a=p.parse_args()
frames=[]
for name in a.experiments:
    root=Path('data/experiments')/name
    try:r=rank(root,allow_incomplete=True,make_plots=False)
    except ValueError:continue
    d=pd.read_csv(root/'design.csv').rename(columns={'scenario':'config_id'})
    q=pd.read_csv(r/'season_composite_scores.csv').merge(d,on='config_id',validate='many_to_one')
    t=pd.read_csv(r/'season_scores.csv');common=t[t.target.isin(['wk inc flu hosp','wk inc covid hosp'])].groupby(['config_id','seed','season','geography']).wis_ratio.mean().rename('shared_flu_covid_admissions_wis_ratio').reset_index()
    q=q.merge(common,on=['config_id','seed','season','geography'],validate='one_to_one');q['experiment']=name;frames.append(q)
if not frames:raise SystemExit('No complete replay runs yet')
q=pd.concat(frames,ignore_index=True).drop_duplicates(['config_id','seed','season','geography'],keep='last')
recipes={x:Scenario.from_string(x) for x in q.config_id.unique()}
q['forecaster_mask_rate']=q.config_id.map(lambda x:recipes[x].mask_rate)
q['nowcaster_refitted']=q.config_id.map(lambda x:recipes[x].fixed_refit_nowcaster)
q['observed_pairs_only']=q.config_id.map(lambda x:recipes[x].correction_observed_pairs_only)
q['refit_correction_strength']=q.config_id.map(lambda x:recipes[x].correction_strength if recipes[x].fixed_refit_nowcaster else float('nan'))
base=q[q.treatment.str.contains('CPU replay control')][['architecture','forecaster_mask_rate','seed','season','geography','combined']].rename(columns={'combined':'matched_cpu_raw'})
q=q.merge(base,on=['architecture','forecaster_mask_rate','seed','season','geography'],how='left',validate='many_to_one');q['paired_change_percent']=100*(q.combined/q.matched_cpu_raw-1)
q['forecaster_model']=q.architecture.map({'C1':'Pathogen-specific MLP; distance sharing; no covariates','C2':'Target-specific MLP; no spatial sharing; summarized inpatient/wastewater/Kinsa/ILINet/clinical labs/FluSurv','C3':'Target-specific MLP; neighbor sharing; summarized Kinsa'})
q['forecaster_training']='Saved model trained on unchanged finalized inputs and finalized t+1..t+4 labels; no retraining'
q['training_seasons']=q.season.map({'2024-2025':'2022-23,2023-24,2025-26','2025-2026':'2022-23,2023-24,2024-25'})
q['nowcaster_training']='Saved model learned final recent histories from full-strength synthetic reporting errors on permitted training trajectories only; full/half refers to applied correction'
q['reporting_error_source']=q.season.map({'2024-2025':'2025-26','2025-2026':'2024-25'})
q.loc[q.treatment.str.contains('CPU replay control'),'nowcaster_training']='None: raw-input CPU replay control'
q.loc[q.treatment.str.contains('CPU replay control'),'reporting_error_source']='None: unchanged finalized forecaster training inputs'
q['evaluation_inputs']='Raw archived Wednesday values under B2 availability/lags; explicit final proxies; corrected treatments replace only latest four target histories, keeping forecaster covariates fixed'
q['execution']='CPU inference with same-seed raw-input CPU replay control; do not substitute saved GPU forecast score as baseline'
out=Path('docs/experiments/nowcast-overnight-20261005');q.to_csv(out/'fixed-forecaster-replay-season-seed-scores.csv',index=False)
keys=['architecture','forecaster_mask_rate','treatment','season','geography']
s=q.groupby(keys).agg(seeds=('seed','nunique'),wis_ratio=('combined','mean'),paired_change_percent=('paired_change_percent','mean'),shared_flu_covid_admissions_wis_ratio=('shared_flu_covid_admissions_wis_ratio','mean')).reset_index()
s.to_csv(out/'fixed-forecaster-replay-summary.csv',index=False)
print(s[s.geography.eq('all')].to_string(index=False))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
for season in ['2024-2025','2025-2026']:
    t=q[q.architecture.eq('C1')&q.season.eq(season)&q.geography.eq('all')]
    t=t[t.forecaster_mask_rate.eq(0)&(t.treatment.str.contains('CPU replay control')|(t.nowcaster_refitted & ~t.observed_pairs_only & t.refit_correction_strength.eq(1)))]
    if not t.nowcaster_refitted.any():continue
    fig,ax=plt.subplots(figsize=(11,6))
    for name,g in t.groupby('treatment'):
        ax.plot(g.seed,g.combined,'o-',label='Raw archived inputs' if 'CPU replay control' in name else 'Nonlinear-corrected target histories')
    ax.set_xticks([42,43,44]);ax.set_xlabel('Training seed; same saved forecaster in each paired comparison')
    ax.set_ylabel('Forecast WIS / matched Hub WIS; lower is better');ax.grid(alpha=.2);ax.legend()
    train='2022–23, 2023–24, '+('2025–26' if season=='2024-2025' else '2024–25');donor='2025–26' if season=='2024-2025' else '2024–25'
    ax.set_title(f'C1: pathogen-specific MLP, distance spatial sharing, no forecaster covariates; evaluate {season}\nForecasters trained on unchanged final inputs and final future labels in {train}',fontsize=10)
    fig.text(.015,.01,f'Forecaster weights stay fixed. Each seed refits a separate nonlinear nowcaster on permitted training trajectories, full-strength reporting errors\nfrom {donor}, and final recent-history labels. The nowcaster uses reported eight-week paths, calendar, location and Kinsa features.\nEvaluation uses archived Wednesday values under B2 availability/lags with explicit final proxies; only target histories are corrected.\nMatched CPU inference and random draws; development-season selection, not untouched seasonal validation.',fontsize=8)
    fig.tight_layout(rect=(0,.12,1,1));fig.savefig(out/f'c1-correction-confirmation-{season}.png',dpi=170);plt.close(fig)
if q.observed_pairs_only.any():
    fig,axes=plt.subplots(1,2,figsize=(14,6),sharey=True)
    conditions=[(False,1.),(False,.5),(True,1.),(True,.5)]
    labels=['Include zero-error fallback cells; full correction','Include zero-error fallback cells; half correction','Observed donor pairs only; full correction','Observed donor pairs only; half correction']
    for ax,season in zip(axes,['2024-2025','2025-2026']):
        t=q[q.architecture.eq('C1')&q.forecaster_mask_rate.eq(0)&q.nowcaster_refitted&q.geography.eq('all')&q.season.eq(season)]
        for i,(observed,strength) in enumerate(conditions):
            g=t[t.observed_pairs_only.eq(observed)&t.refit_correction_strength.eq(strength)]
            if g.empty:continue
            mean=g.paired_change_percent.mean();sd=g.paired_change_percent.std()
            ax.errorbar(mean,i,xerr=0 if pd.isna(sd) else sd,fmt='D',color='#334155',capsize=4)
            for offset,row in enumerate(g.sort_values('seed').itertuples()):ax.scatter(row.paired_change_percent,i+.12*(offset-1),s=22,facecolors='none',edgecolors='#0e7490')
            ax.annotate(f'n={g.seed.nunique()}',(mean,i),xytext=(5,7),textcoords='offset points',fontsize=7)
        ax.axvline(0,color='#94a3b8',ls='--');ax.set_yticks(range(4),labels,fontsize=8);ax.set_ylim(3.5,-.5);ax.grid(axis='x',alpha=.2)
        ax.set_xlabel('Paired forecast WIS change (%) vs raw-input CPU replay; lower is better')
        train='2022–23, 2023–24, '+('2025–26' if season=='2024-2025' else '2024–25');donor='2025–26' if season=='2024-2025' else '2024–25'
        ax.set_title(f'Evaluate {season}; train {train}\nSynthetic reporting errors only from {donor}',fontsize=9)
    fig.suptitle('Fixed C1 forecasters: how donor-pair supervision and correction strength affect forecasts',fontsize=12)
    fig.text(.015,.01,'C1: pathogen-specific MLP, distance sharing, no covariates; trained on unchanged final inputs and final future labels. Forecast weights stay fixed.\nSeparate nonlinear nowcaster: reported eight-week paths, calendar/location/Kinsa; full-strength synthetic inputs and final recent labels; refit per seed.\nObserved-pair treatment filters nowcaster supervision only; real observed zero revisions remain. Half strength halves the predicted log correction.\nEvaluation: archived Wednesday inputs under B2 availability with explicit final proxies. Diamonds/error bars: mean/seed SD; circles: individual seeds. Development evaluation.',fontsize=8)
    fig.tight_layout(rect=(0,.14,1,.95));fig.savefig(out/'donor-pair-supervision-comparison.png',dpi=170);plt.close(fig)
