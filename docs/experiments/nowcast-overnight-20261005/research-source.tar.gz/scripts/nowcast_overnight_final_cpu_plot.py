"""Plot the completed matched2048-draw comparisons; no new scoring."""
from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=Path('docs/experiments/nowcast-overnight-20261005');d=pd.read_csv(p/'principal-comparisons-per-seed.csv');d=d[d.comparison_group.eq('Matched CPU history bank; 2048 draws')]
labels={'40eb78af29b5':'Raw archived histories','efb8ff91d30a':'Mixture: all histories; Kinsa','eec5b242963f':'Mixture: all histories; no covariates','ff001327e617':'Mixture: admissions only; Kinsa','ebbcb2039081':'Mixture: admissions only; no covariates'}
d['label']=d.run_id.str.split('-').str[-1].map(labels)
fig,axes=plt.subplots(1,2,figsize=(13,6))
for ax,season in zip(axes,['2024-2025','2025-2026']):
 for name,g in d[d.season.eq(season)].groupby('label',sort=False):ax.plot(g.seed,g.score,'o-',label=name)
 ax.set_xticks([42,43,44]);ax.set_xlabel('Training seed');ax.set_ylabel('Forecast WIS / matched Hub WIS; lower is better');ax.grid(alpha=.2);ax.legend(fontsize=8);ax.set_title('Evaluate '+season)
fig.suptitle('Fixed strongest C1 forecaster: completed2048-draw CPU comparisons')
fig.text(.01,.01,'C1: pathogen-specific MLPs, distance sharing, no covariates; unchanged finalized training inputs and finalized future labels; saved weights stay fixed.\n2024–25: train2022–23/2023–24/2025–26, error donor2025–26. 2025–26: train2022–23/2023–24/2024–25, donor2024–25.\nSeparate nonlinear nowcaster: full synthetic training errors, final recent labels, reported eight-week paths/calendar/location; Kinsa only where labeled.\nEvaluation: archived Wednesday inputs under B2 lags/availability and explicit final proxies. Equal coherent raw/full histories; ED stays raw in admission-only arms.\nAll arms use identical CPU2048-draw inference. Both seasons used repeatedly for development; three seeds do not establish independent seasonal validation.',fontsize=8)
fig.tight_layout(rect=(0,.17,1,.94));fig.savefig(p/'fixed-c1-final-comparison.png',dpi=170);plt.close(fig)
