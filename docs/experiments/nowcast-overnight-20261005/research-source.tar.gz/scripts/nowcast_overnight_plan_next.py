"""Nowcaster trajectory learning and joint current-level anchoring on strong B2s."""
import argparse,json,subprocess,sys
from dataclasses import replace
from pathlib import Path
import pandas as pd
from tapestry.model.scenario import Scenario
p=argparse.ArgumentParser();p.add_argument('-e','--experiment',required=True);p.add_argument('--seeds',nargs='+',default=['42']);p.add_argument('--backbones',nargs='+',default=['C1','C2','C3']);a=p.parse_args()
r=pd.read_csv('docs/experiments/b-2-t0/named_ranking.csv');r=r[r.label.isin(a.backbones)]
rows=[]
for row in r.itertuples():
    b=replace(Scenario.from_string(row.config_id),supplied_final=False,mask_rate=0.,reporting_missingness=False,reporting_augmentation='vintage')
    arms=[('Separate phase/location ridge nowcaster; full correction; synthetic reports',dict(weekend_family='two_stage',correction_features='phase_local',correction_penalty=1. if row.label=='C2' else 10.,nowcast_weeks=4)),
          ('Separate nonlinear eight-week trajectory nowcaster; full correction; synthetic reports',dict(weekend_family='two_stage',correction_features='trajectory',nowcast_weeks=4)),
          ('Separate nonlinear eight-week trajectory nowcaster; half correction; synthetic reports',dict(weekend_family='two_stage',correction_features='trajectory',correction_strength=.5,nowcast_weeks=4)),
          ('Joint separate recent/future losses; half-strength errors; auxiliary weight0.05',dict(weekend_family='joint',joint_weight=.05,nowcast_weeks=4,reporting_strength=.5)),
          ('Joint t0-linked future uncertainty; four recent labels; half-strength errors; auxiliary weight0.05',dict(weekend_family='joint',joint_weight=.05,nowcast_weeks=4,nowcast_anchor=True,reporting_strength=.5)),
          ('Joint t0-linked future uncertainty; four recent labels; full-strength errors; auxiliary weight0.05',dict(weekend_family='joint',joint_weight=.05,nowcast_weeks=4,nowcast_anchor=True)),
          ('Joint t0-linked future uncertainty; current label only; half-strength errors; auxiliary weight0.05',dict(weekend_family='joint',joint_weight=.05,nowcast_weeks=1,nowcast_anchor=True,reporting_strength=.5)),
          ('Direct unchanged final training inputs; B2 dropout regularization0.2',dict(weekend_family='direct',reporting_probability=0.,mask_rate=.2))]
    for name,kw in arms:
        if row.label=='C1' and kw.get('mask_rate')!=.2:continue
        if row.label=='C2' and kw['weekend_family']=='joint':continue
        s=replace(b,**kw);rows.append(dict(architecture=row.label,treatment=name,family=s.weekend_family,scenario=s.scenario_string,run_id=s.run_id))
folder=Path('data/experiments')/a.experiment
settings=json.loads(Path('data/experiments/b-2-t0/experiment.json').read_text())
cmd=[sys.executable,'-m','tapestry.experiment.planner','plan','-e',a.experiment,'-s',*[x['scenario'] for x in rows],'--seeds',*a.seeds,'--device','cuda','--eval-members','256','--dataset',settings['dataset'],'--frozen',settings['frozen']]
subprocess.run(cmd,check=True)
pd.DataFrame(rows).to_csv(folder/'design.csv',index=False)
print(' '.join(cmd))
