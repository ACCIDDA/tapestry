"""Read completed 2025–26 folds early through the SAME frozen-support scorer.

Does not interrupt fitting, alter predictions or pretend that the second fold
has finished. The manager's ordinary full-run status/rank remain authoritative.
"""
import argparse,json
from pathlib import Path
import pandas as pd
from tapestry.experiment.planner import read_jobs,attempts
from tapestry.evaluation.totals import score_run,rank
p=argparse.ArgumentParser();p.add_argument('-e','--experiment',required=True);a=p.parse_args()
root=Path('data/experiments')/a.experiment;settings=json.loads((root/'experiment.json').read_text())
output=root/'partial-forward';runs=[]
for job in read_jobs(root):
    for seed in job['seeds']:
        eligible=[x for x in attempts(root,job['scenario'],seed) if (x/'eval_2025-2026/forecasts.npz').exists()]
        if not eligible:continue
        source=eligible[-1];dest=output/job['name']/f's{seed}';dest.mkdir(parents=True,exist_ok=True)
        link=dest/'eval_2025-2026'
        if link.is_symlink() and link.resolve()!=(source/'eval_2025-2026').resolve():
            link.unlink();(dest/'totals.csv').unlink(missing_ok=True)
        if not link.exists():link.symlink_to((source/'eval_2025-2026').resolve(),target_is_directory=True)
        (dest/'manifest.json').write_text(json.dumps(dict(scenario=job['scenario'],seed=seed,folds=['2025-2026'],source_attempt=str(source),partial=True)))
        try:
            if not (dest/'totals.csv').exists():score_run(dest,settings['frozen'])
        except Exception as err:
            print(f'Not ready: {source}: {err}');continue
        runs.append(dict(config_id=job['scenario'],seed=seed,path=dest))
if not runs:raise SystemExit('No forward folds ready yet')
rank(runs,output/'ranking')
r=pd.read_csv(output/'ranking/run_scores.csv');d=pd.read_csv(root/'design.csv').rename(columns={'scenario':'config_id'})
q=r.merge(d,on='config_id').query('geography=="all"').sort_values('combined')
q.to_csv(output/'forward-pilot-scores.csv',index=False)
print(q[['architecture','treatment','seed','combined']].to_string(index=False))
