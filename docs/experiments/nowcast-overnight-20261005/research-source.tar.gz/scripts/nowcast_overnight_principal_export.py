"""Export complete three-seed comparisons without mixing inference controls."""
from pathlib import Path
import pandas as pd
p=Path('docs/experiments/nowcast-overnight-20261005')
rows=[]
gpu=pd.read_csv(p/'season-seed-scores.csv');gpu=gpu[gpu.geography.eq('all')]
controls=gpu[gpu.treatment.eq('Direct forecast; unchanged finalized training inputs')].set_index(['architecture','seed','season'])
for (exp,run),g in gpu.groupby(['experiment','run_id']):
 if len(g)!=6 or set(g.seed)!={42,43,44}:continue
 for r in g.itertuples():
  c=controls.loc[(r.architecture,r.seed,r.season)]
  rows.append(dict(comparison_group='H100 GPU; 256 draws',experiment=exp,run_id=run,architecture=r.architecture,treatment=r.treatment,seed=r.seed,season=r.season,score=r.combined,control_score=c.combined,control_experiment=c.experiment,control_run_id=c.run_id,model=r.model,training_seasons=r.training_seasons,training_inputs=r.training_inputs,labels=r.labels,evaluation_inputs=r.evaluation_inputs,nowcaster_covariates='As forecaster covariates for two-stage; otherwise not applicable',reporting_error_source=r.reporting_error_source,predictive_draws=256,hardware='g1803jles02 H100',forecaster_retrained=True))
for prefix,exp in [('mc-check','nowcast-overnight-mc-check-20261005'),('no-cov-admissions','nowcast-overnight-no-cov-admissions-20261005'),('gpu-mixture-check','nowcast-overnight-gpu-mixture-check-20261005')]:
 f=p/f'{prefix}-season-seed-scores.csv'
 if not f.exists():continue
 d=pd.read_csv(f);d=d[d.geography.eq('all')];raw=d[d.treatment.str.contains('control')]
 for run,g in d.groupby('run_id'):
  if len(g)!=6 or set(g.seed)!={42,43,44}:continue
  if prefix=='no-cov-admissions' and g.treatment.str.contains('control').all():continue
  for r in g.itertuples():
   c=raw[(raw.seed==r.seed)&(raw.season==r.season)].iloc[0]
   rows.append(dict(comparison_group=('Matched H100 history bank; 2048 draws' if prefix=='gpu-mixture-check' else 'Matched CPU history bank; 2048 draws'),experiment=exp,run_id=run,architecture='C1',treatment=r.treatment,seed=r.seed,season=r.season,score=r.combined,control_score=c.combined,control_experiment=exp,control_run_id=c.run_id,model=r.forecaster,training_seasons=r.training_seasons,training_inputs='Forecaster: unchanged finalized inputs. Nowcaster if used: full synthetic reporting errors on permitted training trajectories; missing donor pairs retain zero-error fallback.',labels='Forecaster: finalized t+1..t+4. Nowcaster if used: finalized recent histories.',evaluation_inputs=r.evaluation+'; '+r.history_mode+'; corrected channels '+r.corrected_channels,nowcaster_covariates=r.nowcaster_covariates,reporting_error_source=r.error_donor_season,predictive_draws=r.predictive_draws,hardware=('g1803jles02 H100' if prefix=='gpu-mixture-check' else 'g1803jles02 CPU'),forecaster_retrained=False))
f=p/'c1-pipeline-isolation-per-seed.csv'
if f.exists():
 z=pd.read_csv(f);z=z[z.operation.str.startswith('Saved C1')]
 for run,g in z.groupby('run_id'):
  if len(g)!=6 or set(g.seed)!={42,43,44}:continue
  for r in g.itertuples():
   rows.append(dict(comparison_group='Matched H100 point replay; 256 draws',experiment=r.experiment,run_id=run,architecture='C1',treatment=r.treatment,seed=r.seed,season=r.season,score=r.combined,control_score=r.matched_raw,control_experiment=r.experiment,control_run_id=r.control_run_id,model=r.model,training_seasons=r.training_seasons,training_inputs='Saved forecaster: unchanged finalized inputs; nowcaster if used: full synthetic reports from permitted training trajectories',labels=r.labels,evaluation_inputs=r.evaluation+'; correction strength '+str(r.correction_strength),nowcaster_covariates='None',reporting_error_source=r.error_donor_season if r.correction_strength else 'None; raw input control',predictive_draws=256,hardware='g1803jles02 H100',forecaster_retrained=False))
d=pd.DataFrame(rows);d['paired_change_percent']=100*(d.score/d.control_score-1)
d['development_caveat']='Both evaluation seasons repeatedly used for selection; seeds43/44 measure training variability, not independent seasonal validation.'
d.to_csv(p/'principal-comparisons-per-seed.csv',index=False)
keys=['comparison_group','experiment','run_id','architecture','treatment','model','training_inputs','labels','evaluation_inputs','nowcaster_covariates','predictive_draws','hardware','forecaster_retrained','control_experiment','control_run_id','development_caveat']
out=[]
for key,g in d.groupby(keys,dropna=False):
 row=dict(zip(keys,key))
 for season,sg in g.groupby('season'):
  prefix='retrospective_2024_25' if season=='2024-2025' else 'forward_2025_26'
  for name,value in [('mean',sg.score.mean()),('control_mean',sg.control_score.mean()),('mean_paired_change_percent',sg.paired_change_percent.mean()),('seeds',sg.seed.nunique()),('training_seasons',sg.training_seasons.iloc[0]),('reporting_error_source',sg.reporting_error_source.iloc[0])]:row[prefix+'_'+name]=value
 out.append(row)
q=pd.DataFrame(out);q.to_csv(p/'principal-comparisons.csv',index=False)
print(q[['architecture','treatment','retrospective_2024_25_mean','forward_2025_26_mean','forward_2025_26_mean_paired_change_percent']].to_string(index=False))
