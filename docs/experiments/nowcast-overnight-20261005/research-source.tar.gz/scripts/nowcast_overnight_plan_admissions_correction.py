"""Keep ED inputs raw while applying the learned nowcast to admissions histories."""
import argparse,json,subprocess,sys
from pathlib import Path
from dataclasses import replace
import pandas as pd
from tapestry.model.scenario import Scenario
p=argparse.ArgumentParser();p.add_argument('-e','--experiment',required=True);p.add_argument('--seeds',nargs='+',default=['42','43','44']);a=p.parse_args()
source=Path('data/experiments/nowcast-overnight-uncertainty-20261005');design=pd.read_csv(source/'design.csv');settings=json.loads((source/'experiment.json').read_text())
rows=[]
for row in design.itertuples():
 s=Scenario.from_string(row.scenario)
 if s.fixed_history_mode=='point' and s.fixed_nowcaster!='raw' and s.correction_strength==1:continue
 s=replace(s,fixed_correction_channels='admissions')
 rows.append(dict(architecture='C1',treatment=row.treatment+'; correct admissions histories only, keep ED raw',family='fixed_corrected',scenario=s.scenario_string,run_id=s.run_id))
d=pd.read_csv('data/experiments/nowcast-overnight-residual-uncertainty-20261005/design.csv');row=d[d.treatment.str.endswith('strength 0.5')].iloc[0];s=replace(Scenario.from_string(row.scenario),fixed_correction_channels='admissions')
rows.append(dict(architecture='C1',treatment='Half point + cross-fitted residual noise strength 0.5; correct admissions histories only, keep ED raw',family='fixed_corrected',scenario=s.scenario_string,run_id=s.run_id))
cmd=[sys.executable,'-m','tapestry.experiment.planner','plan','-e',a.experiment,'-s',*[r['scenario'] for r in rows],'--seeds',*a.seeds,'--device','cpu','--eval-members','256','--dataset',settings['dataset'],'--frozen',settings['frozen']]
subprocess.run(cmd,check=True);pd.DataFrame(rows).to_csv(Path('data/experiments')/a.experiment/'design.csv',index=False);print(' '.join(cmd))
