"""Collect native-unit correction diagnostics; never substitute these for WIS."""
import argparse
from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=argparse.ArgumentParser();p.add_argument('-e','--experiment',required=True);a=p.parse_args()
root=Path('data/experiments')/a.experiment;out=Path('docs/experiments/nowcast-overnight-20261005');out.mkdir(parents=True,exist_ok=True)
targets=['Flu admissions','COVID admissions','RSV admissions','Flu ED proportion','COVID ED proportion','RSV ED proportion']
rows=[]
for r in pd.read_csv(root/'design.csv').itertuples():
    for f in (root/r.run_id).glob('s*/attempt-*/eval_*/nowcast_diagnostics.csv'):
        q=pd.read_csv(f);q['architecture']=r.architecture;q['treatment']=r.treatment;q['seed']=int(f.parents[2].name[1:]);q['season']=f.parent.name[5:];q['source']=str(f);rows.append(q)
if not rows:raise SystemExit('No correction diagnostics yet')
q=pd.concat(rows,ignore_index=True).drop_duplicates(['architecture','treatment','seed','season','age','channel','geography'],keep='last')
q['target']=q.channel.map(dict(enumerate(targets)));q['mae_ratio']=q.corrected_mae/q.raw_mae
q['training_seasons']=q.season.map({'2024-2025':'2022-23,2023-24,2025-26','2025-2026':'2022-23,2023-24,2024-25'})
q['reporting_error_source']=q.season.map({'2024-2025':'2025-26','2025-2026':'2024-25'})
q['scope']='All eligible seasonal origin/location input cells; not restricted to frozen Hub support; not WIS weighted; explicit final numerical proxies included'
q['training_labels']='Finalized recent histories; reported synthetic trajectories are predictors; corrected training trajectories use season-cross-fitted nowcasters'
q['evaluation_inputs']='Archived Wednesday values under B2 source availability/lags, with explicit final proxies for absent archives; corrector sees no proxy flag'
q.to_csv(out/'trajectory-nowcaster-input-diagnostics.csv',index=False)
for season,part in q[q.age.eq(0)&q.geography.eq('states_dc')].groupby('season'):
    t=part.groupby(['architecture','treatment','target']).mae_ratio.mean().unstack('target')
    fig,axes=plt.subplots(2,3,figsize=(16,8),sharey=True)
    labels=[f'{a}: '+b.replace('Separate ','').replace('; synthetic reports','').replace('eight-week trajectory ','trajectory ') for a,b in t.index]
    for ax,target in zip(axes.flat,targets):
        ax.scatter(t[target],range(len(t)),s=35);ax.axvline(1,c='#64748b',ls='--');ax.set_title(target);ax.grid(axis='x',alpha=.2);ax.set_yticks(range(len(t)),labels,fontsize=7);ax.set_ylim(len(t)-.5,-.5);ax.set_xlabel('Corrected / raw native MAE; lower is better')
    train=part.training_seasons.iloc[0];errors=part.reporting_error_source.iloc[0]
    fig.suptitle(f'Latest-week {season} state/DC input diagnostics across ALL eligible seasonal origins\nNowcaster learns final recent labels from synthetic reports on {train}; reporting errors only from {errors}\nArchived Wednesday evaluation inputs under B2 availability; explicit final proxies included. Not frozen Hub support or forecast WIS.',fontsize=10)
    fig.tight_layout(rect=(0,0,1,.9));fig.savefig(out/f'trajectory-nowcaster-input-diagnostics-{season}.png',dpi=160);plt.close(fig)
print(q[q.age.eq(0)&q.geography.eq('states_dc')][['architecture','treatment','season','seed','target','cells','raw_mae','corrected_mae']].to_string(index=False))
