"""Compact display of three-seed GPU comparisons, excluding exploratory pilots."""
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tapestry.model.scenario import Scenario
out=Path('docs/experiments/nowcast-overnight-20261005');q=pd.read_csv(out/'season-seed-scores.csv');q=q[q.geography.eq('all')]
counts=q.groupby(['config_id','season']).seed.transform('nunique');q=q[counts.eq(3)].copy()
def label(x):
 s=Scenario.from_string(x)
 if s.weekend_family=='direct':return 'Direct; final inputs'+(' + mask .2' if s.mask_rate else '')
 if s.weekend_family=='two_stage':return 'Nonlinear nowcaster + retrained forecast'
 strength='final inputs' if s.reporting_probability==0 else 'half errors' if s.reporting_strength==.5 else 'full errors'
 return f'Joint; {strength}; auxiliary {s.joint_weight:g}'
q['plot_label']=q.config_id.map(label);q.to_csv(out/'confirmed-gpu-season-seed-scores.csv',index=False)
fig,axes=plt.subplots(2,3,figsize=(16,10),sharex=True)
colors={42:'#0284c7',43:'#dc2626',44:'#7c3aed'}
for row,season in enumerate(['2024-2025','2025-2026']):
 reference=q[q.architecture.eq('C1')&q.season.eq(season)&q.plot_label.eq('Direct; final inputs')].combined.mean()
 for col,arch in enumerate(['C1','C2','C3']):
  ax=axes[row,col];t=q[q.season.eq(season)&q.architecture.eq(arch)];labels=sorted(t.plot_label.unique(),key=lambda x:(not x.startswith('Direct; final inputs'),x))
  for i,name in enumerate(labels):
   g=t[t.plot_label.eq(name)].sort_values('seed');ax.scatter(g.combined,np.arange(len(g))*.10+i-.10,c=[colors[x] for x in g.seed],s=28)
   ax.scatter(g.combined.mean(),i,marker='D',color='black',s=30,zorder=5)
  ax.axvline(reference,ls='--',color='#94a3b8',label='C1 direct mean');ax.grid(axis='x',alpha=.2);ax.set_yticks(range(len(labels)),labels,fontsize=8);ax.invert_yaxis();ax.set_title(f'{arch}; evaluate {season}')
  ax.set_xlabel('Forecast WIS / matched Hub WIS; lower is better')
  ax.set_xlim(np.floor((q.combined.min()-.02)*20)/20,np.ceil((q.combined.max()+.02)*20)/20)
fig.suptitle('Confirmed GPU comparisons: three training seeds per condition; all on node2 H100',fontsize=14)
handles=[plt.Line2D([0],[0],marker='o',color='none',markerfacecolor=colors[k],label=f'Seed {k}') for k in colors]+[plt.Line2D([0],[0],marker='D',color='none',markerfacecolor='black',label='Mean')]
fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.5,.955),ncol=4)
fig.text(.015,.01,'Top row: evaluate2024–25; train2022–23,2023–24,2025–26; synthetic reporting errors only2025–26. Bottom: evaluate2025–26; train2022–23,2023–24,2024–25; errors only2024–25.\nC1: pathogen MLP, distance sharing, no covariates. C2: target MLP, no spatial sharing, summarized inpatient/wastewater/Kinsa/ILINet/labs/FluSurv. C3: target MLP, neighbors, Kinsa.\nFinal inputs are unchanged finalized histories; errors perturb training histories only. All learn finalized future labels; joint adds finalized recent labels; auxiliary is reconstruction weight.\nPipeline learns finalized recent histories from full synthetic errors, supplies season-cross-fitted corrected training inputs, and corrects evaluation histories. Other arms evaluate raw reports.\nEvaluation: archived Wednesday values under B2 availability/lags; explicit final proxies. Mask .2 is model regularization, not reporting availability. Development evaluation. Dashed line: C1 direct mean.',fontsize=8)
fig.tight_layout(rect=(0,.13,1,.93));fig.savefig(out/'confirmed-gpu-comparisons.png',dpi=170);plt.close(fig)
