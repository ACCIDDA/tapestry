"""Fixed C1: point histories versus coherent raw/full correction hypotheses."""
import argparse,json,subprocess,sys
from pathlib import Path
from dataclasses import replace
import pandas as pd
from tapestry.model.scenario import Scenario
p=argparse.ArgumentParser();p.add_argument('-e','--experiment',required=True);p.add_argument('--seeds',nargs='+',default=['42','43','44']);a=p.parse_args()
source=Path('data/experiments/nowcast-overnight-pair-support-20261005');design=pd.read_csv(source/'design.csv');settings=json.loads((source/'experiment.json').read_text())
rows=[]
for strength,mode in [(0.,'point'),(.5,'point'),(1.,'point'),(1.,'raw_full_mixture')]:
    if strength==0:
        row=design[design.treatment.str.contains('CPU replay control')].iloc[0]
        s=replace(Scenario.from_string(row.scenario),fixed_history_mode=mode)
        treatment='Raw archived input histories; identical history-bank CPU control'
    else:
        row=design[design.treatment.str.contains('include zero-error fallback cells') & design.treatment.str.endswith(f'correction strength {strength:g}')].iloc[0]
        path=str(source/row.run_id/'s{seed}'/'attempt-001'/'eval_{season}'/'nowcast_correctors.pt')
        s=replace(Scenario.from_string(row.scenario),fixed_nowcaster=path,fixed_refit_nowcaster=False,fixed_history_mode=mode)
        treatment=f'Point nonlinear correction; log strength {strength:g}' if mode=='point' else 'Equal mixture of raw and full nonlinear-corrected histories; coherent global hypothesis per predictive draw'
    rows.append(dict(architecture='C1',treatment=treatment,family='fixed_corrected',scenario=s.scenario_string,run_id=s.run_id))
cmd=[sys.executable,'-m','tapestry.experiment.planner','plan','-e',a.experiment,'-s',*[r['scenario'] for r in rows],'--seeds',*a.seeds,'--device','cpu','--eval-members','256','--dataset',settings['dataset'],'--frozen',settings['frozen']]
subprocess.run(cmd,check=True);pd.DataFrame(rows).to_csv(Path('data/experiments')/a.experiment/'design.csv',index=False)
print(' '.join(cmd))
