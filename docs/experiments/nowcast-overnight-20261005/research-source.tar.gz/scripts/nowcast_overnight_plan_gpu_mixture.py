"""Verify the best CPU correction treatment with matched H1002048 inference."""
import argparse,json,subprocess,sys
from pathlib import Path
from dataclasses import replace
import pandas as pd
from tapestry.model.scenario import Scenario
p=argparse.ArgumentParser();p.add_argument('-e','--experiment',required=True);p.add_argument('--seeds',nargs='+',default=['42','43','44']);a=p.parse_args()
initial=Path('data/experiments/nowcast-overnight-joint-pilot-20261005');source=Path('data/experiments/nowcast-overnight-no-cov-admissions-20261005')
d=pd.read_csv(source/'design.csv');corrected=d[~d.treatment.str.contains('control')].iloc[0];b=Scenario.from_string(corrected.scenario)
nowcaster=str(source/corrected.run_id/'s{seed}'/'attempt-001'/'eval_{season}'/'nowcast_correctors.pt')
s=replace(b,fixed_nowcaster=nowcaster,fixed_refit_nowcaster=False,fixed_nowcaster_covariates='source')
raw=replace(s,fixed_nowcaster='raw',fixed_history_mode='point',fixed_correction_channels='all')
rows=[]
for recipe,label in [(raw,'Raw archived histories; matched H1002048 control'),(s,'Equal raw/full mixture; admissions histories only; saved no-covariate nowcaster identical to CPU comparison; H1002048')]:
 rows.append(dict(architecture='C1',treatment=label,family='fixed_corrected',scenario=recipe.scenario_string,run_id=recipe.run_id))
settings=json.loads((initial/'experiment.json').read_text());cmd=[sys.executable,'-m','tapestry.experiment.planner','plan','-e',a.experiment,'-s',*[r['scenario'] for r in rows],'--seeds',*a.seeds,'--device','cuda','--eval-members','2048','--dataset',settings['dataset'],'--frozen',settings['frozen']]
subprocess.run(cmd,check=True);pd.DataFrame(rows).to_csv(Path('data/experiments')/a.experiment/'design.csv',index=False);print(' '.join(cmd))
