"""Proxy use on each target's frozen Hub-scored origin/location support.

One count per origin/location, irrespective of the number of scored horizons.
These percentages are not WIS-weighted and do not count covariate input cells.
"""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from tapestry.dataset import cv
from tapestry.dataset.build import load
from tapestry.data.geography import STATE_FIPS
from tapestry.model.scenario import Scenario
from tapestry.evaluation.hubs import CHANNEL
from tapestry.evaluation.totals import frozen_cases
p=Path('docs/experiments/nowcast-overnight-20261005');p.mkdir(parents=True,exist_ok=True)
settings=json.loads(Path('data/experiments/b-2-t0/experiment.json').read_text());panel=load(settings['dataset'])
frozen=Path(settings['frozen']);dates=panel['dates'].astype(str);issues=panel['issuance_dates'].astype(str)
locs=list(panel['locations']);rows=[]
for case in frozen_cases(frozen):
    if case['season'] not in ('2024-2025','2025-2026'):continue
    k=CHANNEL[case['target']]
    u=pd.read_parquet(frozen/case['directory']/'units.parquet')[['reference_date','location']].drop_duplicates()
    cells=[]
    for r in u.itertuples():
        day=np.datetime64(str(r.reference_date)[:10])-np.timedelta64(7,'D')
        issue=str(day+np.timedelta64(4,'D'))
        postal='US' if r.location=='US' else STATE_FIPS[str(r.location).zfill(2)]
        li=locs.index(postal);wi=np.searchsorted(issues,issue)
        if wi>=len(issues) or issues[wi]!=issue:raise ValueError(issue)
        for age in range(8):
            event=str(day-np.timedelta64(7*age,'D'));ti=np.searchsorted(dates,event)
            if ti>=len(dates) or dates[ti]!=event:continue
            final=panel['targets'][ti,li,k]
            if not np.isfinite(final):continue
            raw=panel['asof_targets'][wi,ti,li,k]
            cells.append(dict(age=age,geography='US' if postal=='US' else 'states_dc',proxy=not np.isfinite(raw),absolute_error=0. if not np.isfinite(raw) else float(abs(raw-final))))
    z=pd.DataFrame(cells).groupby(['age','geography']).agg(cells=('proxy','size'),final_proxy_fraction=('proxy','mean'),absolute_error_mean=('absolute_error','mean')).reset_index()
    z['season']=case['season'];z['target']=case['target'];rows.append(z)
q=pd.concat(rows);q.to_csv(p/'frozen-support-target-input-audit.csv',index=False)
print(q.query('age==0').to_string(index=False))
