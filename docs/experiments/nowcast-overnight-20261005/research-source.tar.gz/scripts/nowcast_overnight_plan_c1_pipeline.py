"""Missing strongest-backbone comparison: C1 retrained behind nonlinear correction."""
import argparse,json,subprocess,sys
from dataclasses import replace
from pathlib import Path
import pandas as pd
from tapestry.model.scenario import Scenario
p=argparse.ArgumentParser();p.add_argument('-e','--experiment',required=True);p.add_argument('--seeds',nargs='+',default=['42','43','44']);a=p.parse_args()
r=pd.read_csv('docs/experiments/b-2-t0/named_ranking.csv');rows=[]
for strength in [1.,.5]:
    b=Scenario.from_string(r[r.label.eq('C1')].iloc[0].config_id)
    assert b.covariate_set==''
    s=replace(b,supplied_final=False,mask_rate=0.,reporting_missingness=False,reporting_augmentation='vintage',weekend_family='two_stage',correction_features='trajectory',correction_strength=strength,nowcast_weeks=4)
    rows.append(dict(architecture='C1',treatment=f'Separate nonlinear eight-week trajectory nowcaster without covariates; correction strength{strength:g}; C1 retrained on corrected synthetic reports',family='two_stage',scenario=s.scenario_string,run_id=s.run_id))
settings=json.loads(Path('data/experiments/b-2-t0/experiment.json').read_text())
cmd=[sys.executable,'-m','tapestry.experiment.planner','plan','-e',a.experiment,'-s',*[x['scenario'] for x in rows],'--seeds',*a.seeds,'--device','cuda','--eval-members','256','--dataset',settings['dataset'],'--frozen',settings['frozen']]
subprocess.run(cmd,check=True);pd.DataFrame(rows).to_csv(Path('data/experiments')/a.experiment/'design.csv',index=False);print(' '.join(cmd))
