"""Replay saved weekend correctors for input-error diagnosis; never refit them."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from tapestry.dataset import cv
from tapestry.dataset.build import load,covariate_names_for
from tapestry.model.scenario import Scenario
from tapestry.model.revision_regression import RevisionRegression
from tapestry.experiment.weekend import scheduled_reports
root=Path('data/experiments/b2-weekend-20261002')
design=pd.read_csv(root/'design.csv');settings=json.loads((root/'experiment.json').read_text());panel=load(settings['dataset'])
rows=[]
for arch,penalty in [(2,1.),(3,10.)]:
    matches=[]
    for r in design[design.architecture.eq(arch)].itertuples():
        s=Scenario.from_string(r.scenario)
        if s.weekend_family=='two_stage' and s.correction_features=='phase_local' and s.correction_penalty==penalty:matches.append((r,s))
    assert len(matches)==1
    r,s=matches[0];attempt=sorted((root/r.run_id/'s42').glob('attempt-*'))[-1]
    for held in s.scored_seasons:
        manifest=json.loads((attempt/f'eval_{held}/manifest.json').read_text());rec=manifest['corrections']['full']
        model=RevisionRegression(rec['weeks'],rec['penalty'],rec['strength'],rec['features']);model.coefficients=[np.array(x) for x in rec['coefficients']]
        score=cv.fold(panel,s,held).score
        banks={(age,k,geo):[[],[],[],[]] for age in range(4) for k in range(6) for geo in ('states_dc','US')}
        for truth in score:
            raw,_=scheduled_reports(truth,panel,list(covariate_names_for(s.covariate_set)));corrected=model.apply(raw)
            for age in range(4):
                if cv.season(truth['context_dates'][-1-age])!=held:continue
                for k in range(6):
                    for geo in ('states_dc','US'):
                        loc=np.array([x=='US' for x in truth['locations']]);loc=loc if geo=='US' else ~loc
                        ok=truth['available'][-1-age,k]&loc
                        er=raw['values'][-1-age,k,ok]-truth['values'][-1-age,k,ok]
                        ec=corrected['values'][-1-age,k,ok]-truth['values'][-1-age,k,ok]
                        b=banks[age,k,geo];b[0].extend(abs(er));b[1].extend(abs(ec));b[2].extend(er);b[3].extend(ec)
        for (age,k,geo),b in banks.items():
            if not b[0]:continue
            rows.append(dict(architecture=f'C{arch}',season=held,age=age,target=panel['target_names'][k],geography=geo,cells=len(b[0]),raw_mae=float(np.mean(b[0])),corrected_mae=float(np.mean(b[1])),raw_bias=float(np.mean(b[2])),corrected_bias=float(np.mean(b[3])),penalty=penalty))
out=Path('docs/experiments/nowcast-overnight-20261005');out.mkdir(parents=True,exist_ok=True)
q=pd.DataFrame(rows);q.to_csv(out/'saved-ridge-input-correction-audit.csv',index=False)
print(q.query('age==0 and geography=="states_dc" and season=="2025-2026"').to_string(index=False))
