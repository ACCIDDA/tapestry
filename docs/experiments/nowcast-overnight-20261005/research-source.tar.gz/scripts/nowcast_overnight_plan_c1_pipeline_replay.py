"""Matched H100 replay to isolate retraining from supplying corrected histories."""
import argparse,json,subprocess,sys
from pathlib import Path
from dataclasses import replace
import pandas as pd
from tapestry.model.scenario import Scenario
p=argparse.ArgumentParser();p.add_argument('-e','--experiment',required=True);p.add_argument('--seeds',nargs='+',default=['42','43','44']);a=p.parse_args()
initial=Path('data/experiments/nowcast-overnight-joint-pilot-20261005');pipeline=Path('data/experiments/nowcast-overnight-c1-pipeline-20261005')
base=pd.read_csv(initial/'design.csv');clean=base[base.architecture.eq('C1')&base.treatment.eq('Direct forecast; unchanged finalized training inputs')].iloc[0]
b=Scenario.from_string(clean.scenario);fp=str(initial/clean.run_id/'s{seed}'/'attempt-001'/'eval_{season}'/'model.pt');rows=[]
for r in pd.read_csv(pipeline/'design.csv').itertuples():
 strength=Scenario.from_string(r.scenario).correction_strength
 s=replace(b,weekend_family='fixed_corrected',fixed_forecaster=fp,fixed_nowcaster=str(pipeline/r.run_id/'s{seed}'/'attempt-001'/'eval_{season}'/'nowcast_correctors.pt'))
 rows.append(dict(architecture='C1',treatment=f'Saved unchanged-input C1; evaluation-only nonlinear correction strength{strength:g}; same no-covariate corrector as retrained pipeline; H100256',family='fixed_corrected',scenario=s.scenario_string,run_id=s.run_id))
s=replace(b,weekend_family='fixed_corrected',fixed_forecaster=fp,fixed_nowcaster='raw')
rows.append(dict(architecture='C1',treatment='Saved unchanged-input C1; raw archived evaluation control; H100256',family='fixed_corrected',scenario=s.scenario_string,run_id=s.run_id))
settings=json.loads((initial/'experiment.json').read_text())
cmd=[sys.executable,'-m','tapestry.experiment.planner','plan','-e',a.experiment,'-s',*[r['scenario'] for r in rows],'--seeds',*a.seeds,'--device','cuda','--eval-members','256','--dataset',settings['dataset'],'--frozen',settings['frozen']]
subprocess.run(cmd,check=True);pd.DataFrame(rows).to_csv(Path('data/experiments')/a.experiment/'design.csv',index=False);print(' '.join(cmd))
