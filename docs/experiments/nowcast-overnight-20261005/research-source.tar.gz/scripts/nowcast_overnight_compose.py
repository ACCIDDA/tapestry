"""Predeclared RSV component composition, scored on ordinary frozen forward support.

Rule chosen from seed42: clean-input C3 for flu/COVID; weak-joint C3 for RSV.
No fitting or averaging occurs. Seeds43/44 assess training-seed replication only.
"""
import argparse,json
from pathlib import Path
import numpy as np
import pandas as pd
from tapestry.experiment.planner import read_jobs,attempts
from tapestry.evaluation.totals import score_run,rank
p=argparse.ArgumentParser();p.add_argument('command',choices=['plan','score','status','rank']);p.add_argument('-e','--experiment',required=True);p.add_argument('--season',default='2025-2026',choices=['2024-2025','2025-2026']);p.add_argument('--half-errors',action='store_true');p.add_argument('--backbone',choices=['C1','C3'],default='C3');a=p.parse_args()
if a.backbone=='C1' and not a.half_errors:raise ValueError('C1 composition uses the half-error joint follow-up')
root=Path('data/experiments')/a.experiment;suffix='-half-errors' if a.half_errors else '';jointroot=Path('data/experiments/nowcast-overnight-trajectory-pilot-20261005') if a.half_errors else root;out=root/f'rsv-component-composition{suffix}'/a.season;out.mkdir(parents=True,exist_ok=True)
plan=dict(clean='mlp-target-scheduled_final-3dc00878dfac',joint='mlp-target-scheduled_final-7ea1f60d868c',seeds=[42,43,44],folds=[a.season],joint_channels=[2,5],rule='C3 clean-input-trained independent components for flu/COVID; C3 full-error weak-joint auxiliary .05 independent components for RSV',selection='Rule selected from seed42 evaluation; seeds43/44 replicate training randomness on same development evaluation season')
if a.half_errors:
    plan.update(joint='mlp-target-scheduled_final-1c2e24b26cfe',joint_experiment=str(jointroot),rule=plan['rule'].replace('full-error','half-error'),selection='RSV rule selected from full-error seed42 evaluation and applied unchanged to half-error model before its43/44 results; new seeds assess training variability only')
if a.backbone=='C1':
    suffix='-c1-half-errors';jointroot=Path('data/experiments/nowcast-overnight-joint-refine-20261005');out=root/f'rsv-component-composition{suffix}'/a.season;out.mkdir(parents=True,exist_ok=True)
    plan.update(clean='mlp-pathogen-scheduled_final-80b8b346616c',joint='mlp-pathogen-scheduled_final-2c279dd47828',joint_experiment=str(jointroot),
        rule='C1 clean-input-trained flu/COVID pathogen components; C1 half-error weak-joint auxiliary .05 RSV pathogen component',
        selection='RSV rule learned from earlier C3 seed42 evaluation and fixed before C1 half-error outputs; all seeds assess transfer/training variability on same development seasons')
if a.command=='plan':
    (out/'plan.json').write_text(json.dumps(plan,indent=2));print(json.dumps(plan,indent=2));raise SystemExit
if not (out/'plan.json').exists():raise SystemExit('Run plan first')
assert json.loads((out/'plan.json').read_text())==plan
jobs={x['name']:x for x in read_jobs(root)};jointjobs={x['name']:x for x in read_jobs(jointroot)};frozen=json.loads((root/'experiment.json').read_text())['frozen']
for seed in plan['seeds']:
    sources={}
    for name in ['clean','joint']:
        source_root=jointroot if name=='joint' else root
        job=(jointjobs if name=='joint' else jobs)[plan[name]];ready=[x for x in attempts(source_root,job['scenario'],seed) if (x/f'eval_{a.season}/forecasts.npz').exists()]
        if ready:sources[name]=ready[-1]
    dest=out/'rsv-joint-flu-covid-clean'/f's{seed}'
    print(seed,{k:str(v) for k,v in sources.items()},'scored' if (dest/'totals.csv').exists() else 'not scored')
    if a.command!='score' or len(sources)!=2:continue
    arrays={}
    for name,path in sources.items():
        with np.load(path/f'eval_{a.season}/forecasts.npz',allow_pickle=False) as data:arrays[name]={k:data[k] for k in data.files}
    # Joint recent-label episodes include one extra boundary origin. Select the
    # clean model's exact origins; then assert every other scientific field.
    assert arrays['clean'].keys()==arrays['joint'].keys()
    reference=arrays['clean']['context_end'];joint=arrays['joint']
    lookup={d:i for i,d in enumerate(joint['context_end'])}
    take=np.array([lookup[d] for d in reference])
    for key in ['truth','mask','context_end','target_dates']:joint[key]=joint[key][take]
    joint['quantiles']=joint['quantiles'][:,take]
    for key in arrays['clean']:
        if key!='quantiles':np.testing.assert_array_equal(arrays['clean'][key],arrays['joint'][key],err_msg=key)
    mixed=arrays['clean'];mixed['quantiles']=mixed['quantiles'].copy()
    mixed['quantiles'][:,:,:,plan['joint_channels'],:]=arrays['joint']['quantiles'][:,:,:,plan['joint_channels'],:]
    (dest/f'eval_{a.season}').mkdir(parents=True,exist_ok=True)
    np.savez_compressed(dest/f'eval_{a.season}/forecasts.npz',**mixed)
    (dest/'manifest.json').write_text(json.dumps(dict(folds=plan['folds'],seed=seed,composition=plan,sources={k:str(v) for k,v in sources.items()}),indent=2))
    score_run(dest,frozen)
    for name,path in sources.items():
        baseline=out/f'{name}-all-targets'/f's{seed}'
        baseline.mkdir(parents=True,exist_ok=True)
        link=baseline/f'eval_{a.season}'
        if not link.exists():link.symlink_to((path/f'eval_{a.season}').resolve(),target_is_directory=True)
        (baseline/'manifest.json').write_text(json.dumps(dict(folds=plan['folds'],seed=seed)))
        if not (baseline/'totals.csv').exists():score_run(baseline,frozen)
if a.command in ['score','rank']:
    runs=[]
    for seed in plan['seeds']:
        for label,path in [('rsv-joint-flu-covid-clean',out/'rsv-joint-flu-covid-clean'/f's{seed}'),('clean-all-targets',out/'clean-all-targets'/f's{seed}'),('joint-all-targets',out/'joint-all-targets'/f's{seed}')]:
            if (path/'totals.csv').exists():runs.append(dict(config_id=label,seed=seed,path=path))
    if runs:
        rank(runs,out/'ranking')
        scores=pd.read_csv(out/'ranking/run_scores.csv');print(scores.query('geography=="all"')[['config_id','seed','combined']].to_string(index=False))
        report=Path('docs/experiments/nowcast-overnight-20261005');report.mkdir(parents=True,exist_ok=True)
        scores['model']='C1: three independent pathogen-specific MLPs; distance spatial sharing; no covariates' if a.backbone=='C1' else 'C3: six independent target-specific MLPs; neighbor spatial sharing; summarized Kinsa covariate'
        scores['evaluation_season']=a.season
        scores['training_seasons']='2022-23,2023-24,'+('2025-26' if a.season=='2024-2025' else '2024-25')
        scores['reporting_error_source']='2025-26' if a.season=='2024-2025' else '2024-25'
        scores.loc[scores.config_id.eq('clean-all-targets'),'reporting_error_source']='None; unchanged finalized training inputs'
        scores['evaluation_inputs']='Archived Wednesday numerical values under B2 availability/lags; explicit final proxies for absent archives'
        scores['seed_role']=('Predeclared C3-to-C1 rule transfer; same development evaluation seasons' if a.backbone=='C1' else np.where(scores.seed.eq(42),'Rule selection on evaluation season','Training-seed replication on same evaluation season'))
        scores['components']=scores.config_id.map({'clean-all-targets':'All six target MLPs trained on unchanged final inputs, finalized future labels','joint-all-targets':'All six target MLPs trained on full-strength synthetic reports, finalized t-3..t0 reconstruction and t+1..t+4 labels; auxiliary .05','rsv-joint-flu-covid-clean':'Clean-input-trained flu/COVID MLPs, full-strength-synthetic-report-trained weak-joint RSV MLPs (final t-3..t0 reconstruction and t+1..t+4 labels; auxiliary .05); no retraining or averaging'})
        if a.backbone=='C1':scores['components']=scores.components.str.replace('All six target MLPs','All three pathogen MLPs',regex=False)
        if a.half_errors:scores['components']=scores.components.str.replace('full-strength','half-strength',regex=False)
        base=scores[scores.config_id.eq('clean-all-targets')][['seed','geography','combined']].rename(columns={'combined':'matched_clean'})
        scores=scores.merge(base,on=['seed','geography'],how='left',validate='many_to_one')
        scores['paired_change_percent']=100*(scores.combined/scores.matched_clean-1)
        scores.to_csv(report/f'rsv-component-composition{suffix}-{a.season}.csv',index=False)
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        short={'clean-all-targets':'All targets: clean-input training','joint-all-targets':'All targets: weak joint training','rsv-joint-flu-covid-clean':'RSV: weak joint; flu/COVID: clean'}
        fig,ax=plt.subplots(figsize=(11,6))
        for name,g in scores.query('geography=="all"').groupby('config_id'):
            ax.plot(g.seed,g.combined,'o-',label=short[name])
        ax.set_xticks([42,43,44],['42: rule transfer','43: training replication','44: training replication'] if a.backbone=='C1' else ['42: rule-selection seed','43: training replication','44: training replication'])
        ax.set_ylabel('Forecast WIS / matched Hub WIS (lower is better)');ax.grid(alpha=.2);ax.legend()
        train=scores.training_seasons.iloc[0];donor='2025-26' if a.season=='2024-2025' else '2024-25'
        architecture='C1 pathogen-specific MLPs, distance sharing, no covariates' if a.backbone=='C1' else 'C3 target-specific MLPs, neighbor sharing, summarized Kinsa'
        ax.set_title(f'{architecture}; evaluate {a.season}\nTrain seasons {train}; joint training errors only from {donor}',fontsize=10)
        fig.text(.02,.015,('Clean training: unchanged final inputs and final future labels. Joint: full-strength synthetic reports, final t-3..t0 reconstruction and t+1..t+4 labels, auxiliary 0.05.\nEvaluation: archived Wednesday inputs under B2 availability; explicit final proxies for absent archives.\nRSV rule selected from earlier C3 seed42 evaluation; transferred unchanged. Training variability, not independent seasonal validation.').replace('full-strength','half-strength' if a.half_errors else 'full-strength'),fontsize=8)
        fig.tight_layout(rect=(0,.1,1,1));fig.savefig(report/f'rsv-component-composition{suffix}-{a.season}.png',dpi=170);plt.close(fig)
        target_scores=pd.read_csv(out/'ranking/season_scores.csv')
        target_scores.to_csv(report/f'rsv-component-target-scores{suffix}-{a.season}.csv',index=False)
