"""Check separate objectives preserve intended scientific weights."""
from dataclasses import replace
import numpy as np
from tapestry.model.scenario import Scenario
from tapestry.experiment.training import objective_weights
s=Scenario(weekend_family='joint',input_mode='scheduled_final',supplied_final=False,reporting_missingness=False,nowcast_weeks=4,joint_weight=.25)
a=np.ones((8,6,2),dtype=np.float32)
e=dict(target_values=a,Y=np.stack((a,a),axis=2),target_dates=tuple(np.datetime64('2024-01-06')+np.arange(8)*np.timedelta64(7,'D')),locations=('NC','US'))
w=objective_weights([e],s,list(range(6)))
assert np.isclose(w[:,:4].sum(),.25)
assert np.isclose(w[:,4:].sum(),1)
w2=objective_weights([e],replace(s,joint_weight=1.),list(range(6)))
assert np.allclose(w2[:,4:],w[:,4:])
assert np.allclose(w2[:,:4],4*w[:,:4])
assert np.isclose(w[:,4:,:,-1].sum(),.2)
print('PASS: future objective mass1; reconstruction mass0.25/1; US future share0.2; changing reconstruction weight leaves future weights fixed')
