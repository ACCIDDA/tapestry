"""Write transparent season/seed comparisons and graphs without image inspection."""
import argparse
from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tapestry.experiment.planner import rank
from tapestry.model.scenario import Scenario
p=argparse.ArgumentParser();p.add_argument('-e','--experiments',nargs='+',required=True);a=p.parse_args()
out=Path('docs/experiments/nowcast-overnight-20261005');out.mkdir(parents=True,exist_ok=True)
frames=[]
for name in a.experiments:
    folder=Path('data/experiments')/name
    try:r=rank(folder,allow_incomplete=True,make_plots=False)
    except ValueError as err:print(name,err);continue
    design=pd.read_csv(folder/'design.csv').rename(columns={'scenario':'config_id'})
    q=pd.read_csv(r/'season_composite_scores.csv').merge(design,on='config_id',validate='many_to_one')
    target_scores=pd.read_csv(r/'season_scores.csv')
    common=target_scores[target_scores.target.isin(['wk inc flu hosp','wk inc covid hosp'])].groupby(['config_id','seed','season','geography']).wis_ratio.mean().rename('shared_flu_covid_admissions_wis_ratio').reset_index()
    q=q.merge(common,on=['config_id','seed','season','geography'],validate='one_to_one')
    q['experiment']=name;frames.append(q)
if not frames:raise SystemExit('No complete runs yet')
q=pd.concat(frames,ignore_index=True)
# Same scenario can be resumed/confirmed in another experiment. Keep last input.
q=q.drop_duplicates(['config_id','seed','season','geography'],keep='last')
models={'C1':'Pathogen-specific MLP; distance spatial sharing; no covariates','C2':'Target-specific MLP; no spatial sharing; summarized inpatient/wastewater/Kinsa/ILINet/labs/FluSurv','C3':'Target-specific MLP; neighbors; summarized Kinsa'}
q['model']=q.architecture.map(models)
q['training_seasons']=q.season.map({'2024-2025':'2022-23,2023-24,2025-26','2025-2026':'2022-23,2023-24,2024-25'})
q['reporting_error_source']=q.season.map({'2024-2025':'2025-26','2025-2026':'2024-25'})
q['labels']=q.family.map({'joint':'Finalized t-3..t0 and t+1..t+4 (current-only arms: t0 and t+1..t+4)','direct':'Finalized t+1..t+4','two_stage':'Nowcaster: finalized recent history; forecaster: finalized t+1..t+4'})
for config in q.config_id.unique():
    scenario=Scenario.from_string(config)
    if scenario.reporting_probability==0:
        q.loc[q.config_id.eq(config),'reporting_error_source']='None; unchanged finalized training inputs'
    q.loc[q.config_id.eq(config),'training_inputs']=('Unchanged finalized histories' if scenario.reporting_probability==0 else 'Synthetic reports corrected by trajectory-season-cross-fitted nowcaster' if scenario.weekend_family=='two_stage' else f'Synthetic reporting errors at strength {scenario.reporting_strength:g}; source availability unchanged')
    if scenario.weekend_family=='joint':
        q.loc[q.config_id.eq(config),'labels']=f'Finalized recent weeks t{1-scenario.nowcast_weeks:+d} through t0 and future weeks t+1 through t+4'
q['evaluation_inputs']=q.family.map({'joint':'Raw archived Wednesday values; B2 source availability/lags; final proxies for absent archive','direct':'Raw archived Wednesday values; B2 source availability/lags; final proxies for absent archive','two_stage':'Learned correction of archived Wednesday values; B2 source availability/lags; final proxies for absent archive'})
base=q[q.treatment.eq('Direct forecast; unchanged finalized training inputs')][['architecture','seed','season','geography','combined']].rename(columns={'combined':'same_architecture_clean_training_raw_evaluation'})
q=q.merge(base,on=['architecture','seed','season','geography'],how='left',validate='many_to_one')
q['paired_change_percent']=100*(q.combined/q.same_architecture_clean_training_raw_evaluation-1)
q.to_csv(out/'season-seed-scores.csv',index=False)
q.to_csv(out/'shared-admissions-season-seed-scores.csv',index=False)
keys=['architecture','model','family','treatment','season','training_seasons','reporting_error_source','training_inputs','labels','evaluation_inputs','geography']
s=q.groupby(keys,dropna=False).agg(seeds=('seed','nunique'),wis_ratio=('combined','mean'),shared_flu_covid_admissions_wis_ratio=('shared_flu_covid_admissions_wis_ratio','mean'),seed_sd=('combined','std'),paired_change_percent=('paired_change_percent','mean'),paired_seeds=('paired_change_percent','count')).reset_index()
s.to_csv(out/'summary.csv',index=False)
for season,train,errors in [('2024-2025','2022–23, 2023–24, 2025–26','2025–26'),('2025-2026','2022–23, 2023–24, 2024–25','2024–25')]:
    t=s[s.season.eq(season)&s.geography.eq('all')].sort_values(['architecture','wis_ratio'])
    fig,ax=plt.subplots(figsize=(16,max(6,.36*len(t)+2)))
    y=range(len(t));colors=t.family.map({'direct':'#64748b','joint':'#0e7490','two_stage':'#b45309'})
    ax.errorbar(t.wis_ratio,y,xerr=t.seed_sd.fillna(0),fmt='none',ecolor='#94a3b8',capsize=2)
    ax.scatter(t.wis_ratio,y,c=colors,s=30)
    ax.set_yticks(list(y),[f'{r.architecture}: {r.treatment} [n={r.seeds}]' for r in t.itertuples()],fontsize=7)
    ax.invert_yaxis();ax.axvline(1,c='#94a3b8',ls='--');ax.grid(axis='x',alpha=.2)
    ax.set_xlabel('Forecast WIS / matched Hub WIS; lower is better. Error bars: training-seed SD; n=completed seeds.')
    ax.set_title(f'Evaluate {season}; train trajectories and finalized labels on {train}; reporting errors when used from {errors}\nArchived Wednesday evaluation inputs under B2 availability; absent archives use explicit final proxies\nSeparate nowcasters use full-strength synthetic training reports and correct evaluation inputs; joint models add recent finalized labels',fontsize=9)
    fig.text(.01,.01,'C1: pathogen-specific MLP, distance sharing, no covariates. C3: target-specific MLP, neighbor sharing, summarized Kinsa.\nC2: target-specific MLP, no spatial sharing; summarized inpatient, wastewater, Kinsa, ILINet, clinical labs and FluSurv.\nAll forecasters learn unchanged final t+1..t+4 labels. Separate nowcasters learn final recent histories from synthetic reports.',fontsize=8)
    fig.tight_layout(rect=(0,.065,1,1));fig.savefig(out/f'forecast-comparison-{season}.png',dpi=160);plt.close(fig)
print(s[s.geography.eq('all')][['architecture','treatment','season','seeds','wis_ratio','paired_change_percent']].to_string(index=False))
