"""Matched history-bank inference comparisons through the shared scorer."""
import argparse
from pathlib import Path
import pandas as pd
from tapestry.experiment.planner import rank
from tapestry.model.scenario import Scenario
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=argparse.ArgumentParser();p.add_argument('-e','--experiment',required=True);a=p.parse_args();root=Path('data/experiments')/a.experiment
residual='residual-uncertainty' in a.experiment
prefix=next((x for x in ['gpu-mixture-check','residual-uncertainty','admissions-correction','covariate-ablation','mc-check','no-cov-admissions'] if x in a.experiment),'uncertainty')
r=rank(root,allow_incomplete=True,make_plots=False)
d=pd.read_csv(root/'design.csv').rename(columns={'scenario':'config_id'})
q=pd.read_csv(r/'season_composite_scores.csv').merge(d,on='config_id',validate='many_to_one')
base=q[q.treatment.str.contains('control')][['seed','season','geography','combined']].rename(columns={'combined':'matched_raw'})
q=q.merge(base,on=['seed','season','geography'],validate='many_to_one');q['paired_change_percent']=100*(q.combined/q.matched_raw-1)
t=pd.read_csv(r/'season_scores.csv');common=t[t.target.isin(['wk inc flu hosp','wk inc covid hosp'])].groupby(['config_id','seed','season','geography']).wis_ratio.mean().rename('shared_flu_covid_admissions_wis_ratio').reset_index();q=q.merge(common,on=['config_id','seed','season','geography'],validate='one_to_one')
q['training_seasons']=q.season.map({'2024-2025':'2022-23,2023-24,2025-26','2025-2026':'2022-23,2023-24,2024-25'})
q['error_donor_season']=q.season.map({'2024-2025':'2025-26','2025-2026':'2024-25'})
q['forecaster']='Saved C1 pathogen-specific MLP, distance sharing, no covariates; trained on unchanged final inputs/future labels; no retraining'
q['nowcaster']='Saved per-seed nonlinear trajectory nowcaster; full synthetic errors on permitted training trajectories; final recent-history labels; all synthetic supervised cells'
import json
members=json.loads((root/'experiment.json').read_text())['eval_members']
q['predictive_draws']=members
q['evaluation']='Archived Wednesday values under B2 availability/lags and explicit final proxies; same history-bank inference (draw count recorded separately); correction affects only target histories'
recipes={x:Scenario.from_string(x) for x in q.config_id.unique()}
q['nowcaster_covariates']=q.config_id.map(lambda x:'None' if recipes[x].fixed_nowcaster_covariates=='none' else 'Kinsa')
if prefix=='gpu-mixture-check':
 for sc in recipes.values():
  if sc.fixed_nowcaster=='raw':continue
  source=Path(sc.fixed_nowcaster.format(seed=42,season='2025-2026')).parent/'manifest.json'
  assert Scenario.from_string(json.loads(source.read_text())['corrector_source_scenario']).covariate_set==''
 q['nowcaster_covariates']='None'
q['hardware']='g1803jles02 H100' if json.loads((root/'experiment.json').read_text())['device']=='cuda' else 'g1803jles02 CPU'
q['corrected_channels']=q.config_id.map(lambda x:recipes[x].fixed_correction_channels)
q['history_mode']=q.config_id.map(lambda x:recipes[x].fixed_history_mode)
q['mixture_interpretation']=q.history_mode.map({'point':'Point history','raw_full_mixture':'Equal coherent raw/full hypotheses; sensitivity distribution, not calibrated posterior','crossfit_residual':'Cross-fitted synthetic residuals; median centered and season-balanced; no evaluation-label calibration'})
q.loc[q.treatment.str.contains('control'),['nowcaster','nowcaster_covariates','error_donor_season']]='None: raw-input control'
out=Path('docs/experiments/nowcast-overnight-20261005');q.to_csv(out/f'{prefix}-season-seed-scores.csv',index=False)
s=q.groupby(['treatment','season','geography']).agg(seeds=('seed','nunique'),wis_ratio=('combined','mean'),paired_change_percent=('paired_change_percent','mean'),shared_flu_covid_admissions_wis_ratio=('shared_flu_covid_admissions_wis_ratio','mean')).reset_index();s.to_csv(out/f'{prefix}-summary.csv',index=False)
print(s[s.geography.eq('all')].to_string(index=False))
fig,axes=plt.subplots(1,2,figsize=(13,6),sharey=False)
labels={}
for row in d.itertuples():
 sc=recipes.get(row.config_id)
 if sc is None:continue
 if sc.fixed_nowcaster=='raw':label='Raw history'
 elif sc.fixed_history_mode=='raw_full_mixture':label='Raw/full mixture'
 elif sc.fixed_history_mode=='crossfit_residual':label=f'Half correction; residual noise ×{sc.fixed_uncertainty_strength:g}'
 else:label='Half point correction' if sc.correction_strength==.5 else 'Full point correction'
 if prefix in ('covariate-ablation','mc-check','no-cov-admissions','gpu-mixture-check') and sc.fixed_nowcaster!='raw':label+='; '+('no covariates' if sc.fixed_nowcaster_covariates=='none' or prefix=='gpu-mixture-check' else 'Kinsa')
 if prefix=='mc-check' and sc.fixed_nowcaster!='raw':label+='; '+sc.fixed_correction_channels+' channels'
 labels[row.treatment]=label
for ax,season in zip(axes,['2024-2025','2025-2026']):
 for name,g in q[q.season.eq(season)&q.geography.eq('all')].groupby('treatment'):
  ax.plot(g.seed,g.combined,'o-',label=labels[name])
 ax.set_xticks([42,43,44]);ax.set_xlabel('Training seed');ax.set_ylabel('Forecast WIS / matched Hub WIS; lower is better');ax.grid(alpha=.2);ax.legend(fontsize=8)
 train='2022–23, 2023–24, '+('2025–26' if season=='2024-2025' else '2024–25');donor='2025–26' if season=='2024-2025' else '2024–25'
 ax.set_title(f'Evaluate {season}; train {train}\nReporting-error donor {donor} only',fontsize=9)
titles={'gpu-mixture-check':f'H100 confirmation with {members} draws; admission histories only','uncertainty':'Point corrections versus coherent raw/full uncertainty','residual-uncertainty':'Half correction with cross-fitted synthetic residual uncertainty','admissions-correction':'Correct admissions histories; leave ED histories raw','covariate-ablation':'Does correction depend on Kinsa in the nowcaster?','mc-check':f'Monte Carlo check with {members} predictive draws','no-cov-admissions':f'No-covariate nowcaster; admission histories only; {members} draws'}
fig.suptitle('Fixed C1: '+titles[prefix])
fig.text(.015,.01,f'C1: pathogen-specific MLP, distance sharing, no covariates; unchanged finalized training inputs and finalized future labels. Forecast weights stay fixed.\nSeparate nonlinear nowcaster: reported eight-week paths, calendar/location; Kinsa unless labeled no covariates; full synthetic inputs and finalized recent labels; fitted per seed.\nEvaluation: archived Wednesday inputs with B2 source availability/lags and explicit final proxies. All arms use identical history-bank inference and {members} draws.\nUncertainty is derived from permitted training data or predefined hypotheses; no evaluation-label calibration. Development-season comparisons.',fontsize=8)
fig.tight_layout(rect=(0,.13,1,.95));fig.savefig(out/f'{prefix}-propagation-comparison.png',dpi=170);plt.close(fig)
