"""Reduce Monte Carlo error for raw and preselected coherent-correction mixtures."""
import argparse,json,subprocess,sys
from pathlib import Path
import pandas as pd
from tapestry.model.scenario import Scenario
p=argparse.ArgumentParser();p.add_argument('-e','--experiment',required=True);p.add_argument('--seeds',nargs='+',default=['42','43','44']);p.add_argument('--eval-members',type=int,default=2048);a=p.parse_args()
root=Path('data/experiments');source=root/'nowcast-overnight-uncertainty-20261005';settings=json.loads((source/'experiment.json').read_text());rows=[]
for exp,choose in [('nowcast-overnight-uncertainty-20261005',lambda s:s.fixed_nowcaster=='raw' or s.fixed_history_mode=='raw_full_mixture'),('nowcast-overnight-admissions-correction-20261005',lambda s:s.fixed_history_mode=='raw_full_mixture'),('nowcast-overnight-covariate-ablation-v2-20261005',lambda s:s.fixed_nowcaster_covariates=='none')]:
 for row in pd.read_csv(root/exp/'design.csv').itertuples():
  sc=Scenario.from_string(row.scenario)
  if choose(sc):rows.append(dict(architecture='C1',treatment=row.treatment+f'; {a.eval_members} predictive draws',family='fixed_corrected',scenario=sc.scenario_string,run_id=sc.run_id))
cmd=[sys.executable,'-m','tapestry.experiment.planner','plan','-e',a.experiment,'-s',*[r['scenario'] for r in rows],'--seeds',*a.seeds,'--device','cpu','--eval-members',str(a.eval_members),'--dataset',settings['dataset'],'--frozen',settings['frozen']]
subprocess.run(cmd,check=True);pd.DataFrame(rows).to_csv(root/a.experiment/'design.csv',index=False);print(' '.join(cmd))
