"""Common-manager inference-only replays using explicit frozen source files."""
import argparse,json,subprocess,sys
from pathlib import Path
from dataclasses import replace
import pandas as pd
from tapestry.model.scenario import Scenario
p=argparse.ArgumentParser();p.add_argument('-e','--experiment',required=True);p.add_argument('--seeds',nargs='+',default=['42']);p.add_argument('--c1-only',action='store_true');p.add_argument('--refit-c1-full',action='store_true');a=p.parse_args()
if a.refit_c1_full:a.c1_only=True
initial=Path('data/experiments/nowcast-overnight-joint-pilot-20261005');second=Path('data/experiments/nowcast-overnight-trajectory-pilot-20261005')
base=pd.read_csv(initial/'design.csv');stage=pd.read_csv(second/'design.csv');rows=[]
for r in stage[stage.family.eq('two_stage')].itertuples():
    if a.c1_only and r.architecture!='C3':continue
    if a.refit_c1_full and not (Scenario.from_string(r.scenario).correction_features=='trajectory' and Scenario.from_string(r.scenario).correction_strength==1.):continue
    arch='C1' if a.c1_only else r.architecture
    clean=base[base.architecture.eq(arch)&base.treatment.eq('Direct forecast; unchanged finalized training inputs')].iloc[0]
    b=Scenario.from_string(clean.scenario)
    forecaster=str(initial/clean.run_id/'s{seed}'/'attempt-001'/'eval_{season}'/'model.pt')
    nowcaster=str(second/r.run_id/'s{seed}'/'attempt-001'/'eval_{season}'/'nowcast_correctors.pt')
    s=replace(b,weekend_family='fixed_corrected',fixed_forecaster=forecaster,fixed_nowcaster=nowcaster)
    if a.refit_c1_full:s=replace(s,fixed_refit_nowcaster=True,fixed_nowcaster=nowcaster.replace('s{seed}','s42'))
    name='Existing clean-input forecaster; evaluation-only '+r.treatment.removeprefix('Separate ').replace('; synthetic reports','')
    if a.refit_c1_full:name+='; nowcaster refitted per seed'
    rows.append(dict(architecture=arch,treatment=name,family='fixed_corrected',scenario=s.scenario_string,run_id=s.run_id))
for arch in (['C1'] if a.c1_only else ['C2','C3']):
    clean=base[base.architecture.eq(arch)&base.treatment.eq('Direct forecast; unchanged finalized training inputs')].iloc[0]
    b=Scenario.from_string(clean.scenario)
    s=replace(b,weekend_family='fixed_corrected',fixed_forecaster=str(initial/clean.run_id/'s{seed}'/'attempt-001'/'eval_{season}'/'model.pt'),fixed_nowcaster='raw')
    rows.append(dict(architecture=arch,treatment='Existing clean-input forecaster; raw archived evaluation inputs; CPU replay control',family='fixed_corrected',scenario=s.scenario_string,run_id=s.run_id))
settings=json.loads((initial/'experiment.json').read_text())
cmd=[sys.executable,'-m','tapestry.experiment.planner','plan','-e',a.experiment,'-s',*[r['scenario'] for r in rows],'--seeds',*a.seeds,'--device','cpu','--eval-members','256','--dataset',settings['dataset'],'--frozen',settings['frozen']]
subprocess.run(cmd,check=True)
pd.DataFrame(rows).to_csv(Path('data/experiments')/a.experiment/'design.csv',index=False)
print(' '.join(cmd))
