"""Descriptive frozen-task time decomposition; official score is unchanged."""
import argparse,json
from pathlib import Path
import numpy as np
import pandas as pd
from tapestry.evaluation.totals import forecast_cells,cells_totals,season_scores,season_composites,TARGET_WEIGHTS
from tapestry.experiment.planner import read_jobs,attempts
p=argparse.ArgumentParser();p.add_argument('action',choices=['plan','score','status','rank']);p.add_argument('-e',default='nowcast-overnight-mc-check-20261005');a=p.parse_args()
root=Path('data/experiments')/a.e;out=Path('docs/experiments/nowcast-overnight-20261005');dest=out/'mc-time-contributions.csv'
if a.action=='plan':print('Decompose12 completed CPU2048 runs on frozen tasks;3seeds,2seasons. No model fit or score change.');raise SystemExit
if a.action=='status':print('complete' if dest.exists() else 'not scored',dest);raise SystemExit
if a.action=='score':
 settings=json.loads((root/'experiment.json').read_text());frames=[];checks=[]
 for job in read_jobs(root):
  for seed in job['seeds']:
   run=next(x for x in reversed(attempts(root,job['scenario'],seed)) if (x/'totals.csv').exists())
   cells=forecast_cells(run,settings['frozen']);parts=[]
   for (season,target),g in cells.groupby(['season','target']):
    den=g.groupby('location').ensemble_wis.sum();us=den.index=='US';w=pd.Series(np.where(us,.2,.8/max(1,(~us).sum())),index=den.index);w/=w.sum()
    tw=TARGET_WEIGHTS[target]/sum(TARGET_WEIGHTS[t] for t in cells[cells.season.eq(season)].target.unique())
    g=g.copy();g['contribution']=g.model_wis/g.location.map(den)*g.location.map(w)*tw
    parts.append(g.groupby('reference_date').contribution.sum().reset_index().assign(season=season,target=target))
   q=pd.concat(parts).groupby(['season','reference_date']).contribution.sum().reset_index()
   official=season_composites(season_scores(cells_totals(cells).assign(config_id=job['scenario'],seed=seed)))
   official=official[official.geography.eq('all')].set_index('season').combined
   recomputed=q.groupby('season').contribution.sum();err=float((recomputed-official).abs().max());assert err<1e-10,(run,err)
   checks.append(dict(run=str(run),max_absolute_score_difference=err));frames.append(q.assign(config_id=job['scenario'],seed=seed))
 d=pd.concat(frames);design=pd.read_csv(root/'design.csv').rename(columns={'scenario':'config_id'});d=d.merge(design,on='config_id',validate='many_to_one');d.to_csv(dest,index=False);(out/'mc-time-score-parity.json').write_text(json.dumps(checks,indent=2));print('Wrote',dest);raise SystemExit
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
q=pd.read_csv(dest);raw=q[q.treatment.str.contains('control')][['season','seed','reference_date','contribution']].rename(columns={'contribution':'raw_contribution'})
q=q.merge(raw,on=['season','seed','reference_date'],validate='many_to_one');den=raw.groupby(['season','seed']).raw_contribution.sum().rename('raw_score').reset_index();q=q.merge(den,on=['season','seed']);q['paired_percentage_point_contribution']=100*(q.contribution-q.raw_contribution)/q.raw_score
q.to_csv(out/'mc-time-paired-contributions.csv',index=False)
fig,axes=plt.subplots(1,2,figsize=(13,6))
for ax,season in zip(axes,['2024-2025','2025-2026']):
 for treatment,g in q[q.season.eq(season)&~q.treatment.str.contains('control')].groupby('treatment'):
  label='Admissions only; Kinsa' if 'admissions' in treatment else ('All channels; no covariates' if 'no covariate' in treatment else 'All channels; Kinsa')
  t=g.groupby('reference_date').paired_percentage_point_contribution.mean().sort_index();ax.plot(pd.to_datetime(t.index),t.cumsum(),label=label)
 ax.axhline(0,color='gray',lw=.7);ax.set_title('Evaluate '+season);ax.set_ylabel('Cumulative paired change (% of raw seasonal score)');ax.set_xlabel('Frozen Hub reference date');ax.grid(alpha=.2);ax.legend(fontsize=8);ax.tick_params(axis='x',rotation=30)
fig.suptitle('When fixed-C1 raw/full correction mixtures change the official score')
fig.text(.01,.01,'Mean of seeds42/43/44; negative improves. Saved C1 pathogen MLPs/distance/no covariates; unchanged final training inputs and future labels.\n2024–25 evaluation: train2022–23/2023–24/2025–26, error donor2025–26. 2025–26 evaluation: train2022–23/2023–24/2024–25, error donor2024–25.\nNonlinear nowcaster: synthetic full errors, finalized recent labels, reported paths/calendar/location, Kinsa where stated. Archived Wednesday evaluation with B2 lags/final proxies.\nCPU2048 draws; equal coherent raw/full hypotheses. Whole-season denominators and official location/target weights stay fixed; descriptive development analysis.',fontsize=8)
fig.tight_layout(rect=(0,.15,1,.94));fig.savefig(out/'mc-time-contributions.png',dpi=170);plt.close(fig)
print(q.groupby(['treatment','season','seed']).paired_percentage_point_contribution.sum().groupby(['treatment','season']).mean().to_string())
