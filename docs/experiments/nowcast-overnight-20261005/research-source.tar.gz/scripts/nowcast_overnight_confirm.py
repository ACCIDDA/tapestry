"""Extend seeds of an existing pinned recipe without replacing a live code snapshot."""
import argparse,json
from pathlib import Path
from tapestry.experiment.dispatch import queue_lock
from tapestry.experiment.planner import read_jobs,write_jobs,save
p=argparse.ArgumentParser();p.add_argument('-e','--experiment',required=True);p.add_argument('--run-id',required=True);p.add_argument('--seeds',type=int,nargs='+',default=[42,43,44]);a=p.parse_args()
root=Path('data/experiments')/a.experiment
with queue_lock(root):
    jobs=read_jobs(root);matches=[j for j in jobs if j['name']==a.run_id]
    if len(matches)!=1:raise ValueError('Confirmation must refer to one already-pinned recipe')
    job=matches[0];job['seeds']=sorted(set(job['seeds'])|set(a.seeds))
    state=json.loads((root/'dispatch.json').read_text()) if (root/'dispatch.json').exists() else None
    if state is not None:
        entry=state['tasks'][str(job['task'])]
        for seed in a.seeds:entry['seeds'].setdefault(str(seed),'pending')
    write_jobs(root,jobs)
    if state is not None:save(root/'dispatch.json',state)
    save(root/f'confirmed-{a.run_id}.json',dict(scenario=job['scenario'],seeds=job['seeds'],reason='Forward-season development pilot; confirm against three-seed matched control',code_snapshot_replaced=False))
print(json.dumps(dict(task=job['task'],scenario=job['scenario'],seeds=job['seeds'])))
