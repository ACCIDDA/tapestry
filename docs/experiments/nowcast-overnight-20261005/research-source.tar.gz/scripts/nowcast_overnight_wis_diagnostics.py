"""Explain fixed-C1 uncertainty changes using shared-scorer WIS components."""
from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tapestry.experiment.planner import rank
from tapestry.model.scenario import Scenario
frames=[]
for exp in ['nowcast-overnight-uncertainty-20261005','nowcast-overnight-residual-uncertainty-20261005']:
 root=Path('data/experiments')/exp;r=rank(root,allow_incomplete=False,make_plots=False);q=pd.read_csv(r/'season_scores.csv');d=pd.read_csv(root/'design.csv').rename(columns={'scenario':'config_id'});q=q.merge(d,on='config_id',validate='many_to_one');q['experiment']=exp;frames.append(q)
q=pd.concat(frames).drop_duplicates(['config_id','seed','season','target','geography'],keep='last');q=q[q.geography.eq('all')]
def label(x):
 s=Scenario.from_string(x)
 if s.fixed_nowcaster=='raw':return 'Raw'
 if s.fixed_history_mode=='raw_full_mixture':return 'Raw/full mixture'
 if s.fixed_history_mode=='crossfit_residual':return f'Half + residual ×{s.fixed_uncertainty_strength:g}'
 return 'Half point' if s.correction_strength==.5 else 'Full point'
q['input_treatment']=q.config_id.map(label)
# Half-point saved/refit recipes repeat the same scientific condition.
q=q.drop_duplicates(['input_treatment','seed','season','target','geography'],keep='last')
q['model']='Fixed C1 pathogen MLPs; distance sharing; no covariates; unchanged final forecaster training inputs/future labels'
q['training_seasons']=q.season.map({'2024-2025':'2022-23,2023-24,2025-26','2025-2026':'2022-23,2023-24,2024-25'})
q['error_donor_season']=q.season.map({'2024-2025':'2025-26','2025-2026':'2024-25'})
q['nowcaster']='Nonlinear reported trajectory/calendar/location/Kinsa model; full synthetic errors; final recent labels; per-seed fit'
q['eval_inputs']='Archived Wednesday values under B2 availability/lags; explicit final proxies; target histories corrected only'
out=Path('docs/experiments/nowcast-overnight-20261005');q.to_csv(out/'fixed-c1-target-wis-components.csv',index=False)
cols=['wis_ratio','model_underprediction_ratio','model_overprediction_ratio','model_dispersion_ratio','model_coverage_90']
s=q.groupby(['season','target','input_treatment'])[cols].mean().reset_index();s.to_csv(out/'fixed-c1-target-wis-component-means.csv',index=False)
targets=['wk inc flu hosp','wk inc covid hosp','wk inc rsv hosp','wk inc flu prop ed visits','wk inc covid prop ed visits','wk inc rsv prop ed visits'];names=['Flu admissions','COVID admissions','RSV admissions','Flu ED proportion','COVID ED proportion','RSV ED proportion'];arms=['Raw','Half point','Raw/full mixture','Half + residual ×0.5']
fig,axes=plt.subplots(2,3,figsize=(14,8))
for ax,target,title in zip(axes.flat,targets,names):
 t=s[s.season.eq('2025-2026')&s.target.eq(target)].set_index('input_treatment').loc[arms];bottom=0
 for c,color,name in [('model_underprediction_ratio','#0284c7','Underprediction'),('model_overprediction_ratio','#dc2626','Overprediction'),('model_dispersion_ratio','#94a3b8','Dispersion')]:
  ax.bar(range(len(arms)),t[c],bottom=bottom,label=name,color=color);bottom=bottom+t[c]
 for i,row in enumerate(t.itertuples()):ax.text(i,row.wis_ratio+.015,f'{row.wis_ratio:.3f}\n90% cov {row.model_coverage_90:.0%}',ha='center',fontsize=7)
 ax.set_xticks(range(len(arms)),['Raw','Half\npoint','Raw/full\nmixture','Half +\nresidual .5'],fontsize=8);ax.set_title(title);ax.set_ylim(0,bottom.max()*1.2);ax.set_ylabel('WIS component / Hub WIS');ax.grid(axis='y',alpha=.2)
axes[0,0].legend(fontsize=8)
fig.suptitle('Fixed C1 forecasts in2025–26: where correction and uncertainty change WIS',fontsize=13)
fig.text(.01,.01,'Three-seed means. C1: pathogen MLPs, distance sharing, no covariates; trained on unchanged finalized inputs/future labels in2022–23,2023–24,2024–25.\nSeparate nonlinear nowcaster: reported eight-week paths/calendar/location/Kinsa; same training trajectories, synthetic errors only2024–25, finalized recent labels.\nForecast weights remain fixed. Evaluation: archived Wednesday inputs under B2 availability/lags with explicit final proxies; only target histories change.\nMixture: equal coherent raw/full hypotheses. Residuals: cross-fitted synthetic trajectory residuals. Neither is calibrated using evaluation labels. Development comparison.',fontsize=8)
fig.tight_layout(rect=(0,.11,1,.95));fig.savefig(out/'fixed-c1-wis-components-2025-2026.png',dpi=170);plt.close(fig)
print(s[s.season.eq('2025-2026')].to_string(index=False))
