"""Count completed recipe-seed tasks, retaining device and draw distinctions."""
import json
from datetime import datetime,timezone
from pathlib import Path
import pandas as pd
from tapestry.experiment.planner import collect
from tapestry.model.scenario import Scenario
rows=[]
for root in sorted(Path('data/experiments').glob('nowcast-overnight-*')):
 if not (root/'jobs.csv').exists():continue
 settings=json.loads((root/'experiment.json').read_text())
 for r in collect(root):
  s=Scenario.from_string(r['scenario']);r.update(experiment=root.name,predictive_draws=settings['eval_members'],device=settings['device'],kind='fixed_forecaster_replay' if s.weekend_family=='fixed_corrected' else 'forecaster_retraining',refit_nowcaster=s.fixed_refit_nowcaster);rows.append(r)
d=pd.DataFrame(rows);out=Path('docs/experiments/nowcast-overnight-20261005');d.to_csv(out/'run-inventory.csv',index=False)
done=d[d.status.eq('complete')];unique=done.drop_duplicates(['scenario','seed','predictive_draws','device'])
summary=dict(recorded_utc=datetime.now(timezone.utc).isoformat(),completed_tasks_by_kind=done.groupby('kind').size().to_dict(),unique_recipe_seed_draw_device_by_kind=unique.groupby('kind').size().to_dict(),completed_replay_nowcaster_refits=int(done[done.kind.eq('fixed_forecaster_replay')].refit_nowcaster.sum()),all_task_status_counts=d.status.value_counts().to_dict(),definition='One task covers both seasonal folds. Exact recipe/seed/draw/device deduplication does not imply independent scientific comparisons. Component compositions and derived audits are additional reuses, not fits.')
(out/'run-inventory-summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
