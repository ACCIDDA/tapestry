"""Complete correction-scope by nowcaster-covariate comparison at2048draws."""
import argparse,json,subprocess,sys
from dataclasses import replace
from pathlib import Path
import pandas as pd
from tapestry.model.scenario import Scenario
p=argparse.ArgumentParser();p.add_argument('-e','--experiment',required=True);p.add_argument('--seeds',nargs='+',default=['42','43','44']);a=p.parse_args()
root=Path('data/experiments');source=root/'nowcast-overnight-mc-check-20261005';settings=json.loads((source/'experiment.json').read_text());rows=[]
for row in pd.read_csv(source/'design.csv').itertuples():
 s=Scenario.from_string(row.scenario)
 if s.fixed_nowcaster_covariates=='none':
  s=replace(s,fixed_correction_channels='admissions');name='Coherent raw/full correction mixture; no nowcaster covariates; correct admissions histories only, keep ED raw;2048draws'
 elif s.fixed_nowcaster=='raw':name='Raw archived input histories; identical history-bank CPU control;2048draws'
 else:continue
 rows.append(dict(architecture='C1',treatment=name,family='fixed_corrected',scenario=s.scenario_string,run_id=s.run_id))
cmd=[sys.executable,'-m','tapestry.experiment.planner','plan','-e',a.experiment,'-s',*[r['scenario'] for r in rows],'--seeds',*a.seeds,'--device','cpu','--eval-members','2048','--dataset',settings['dataset'],'--frozen',settings['frozen']]
subprocess.run(cmd,check=True);pd.DataFrame(rows).to_csv(root/a.experiment/'design.csv',index=False);print(' '.join(cmd))
