"""Descriptive US trajectories for a preselected seed, not a new scoring rule."""
from pathlib import Path
import json
import numpy as np
import torch
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tapestry.model.scenario import Scenario
from tapestry.dataset import cv
from tapestry.dataset.build import load
from tapestry.experiment.weekend import scheduled_reports
root=Path('data/experiments');season='2025-2026';seed=42
mc=root/'nowcast-overnight-mc-check-20261005'
base=mc/'mlp-pathogen-scheduled_final-40eb78af29b5'/f's{seed}'/'attempt-001'/f'eval_{season}'/'forecasts.npz'
mix=mc/'mlp-pathogen-scheduled_final-eec5b242963f'/f's{seed}'/'attempt-001'/f'eval_{season}'/'forecasts.npz'
a=np.load(base);b=np.load(mix)
for key in a.files:
 if key!='quantiles':np.testing.assert_array_equal(a[key],b[key],err_msg=key)
checkpoint=root/'nowcast-overnight-covariate-ablation-v2-20261005'/'mlp-pathogen-scheduled_final-eec5b242963f'/f's{seed}'/'attempt-001'/f'eval_{season}'
corrector=torch.load(checkpoint/'nowcast_correctors.pt',map_location='cpu',weights_only=False)['final'];metadata=json.loads((checkpoint/'manifest.json').read_text());s=Scenario.from_string(metadata['corrector_source_scenario']);assert not s.covariate_set
panel=load(json.loads((mc/'experiment.json').read_text())['dataset']);fold=cv.fold(panel,s,season)
raw=[scheduled_reports(e,panel,[])[0] for e in fold.score];est=corrector.apply_batch(raw)
np.testing.assert_array_equal([e['context_dates'][-1] for e in raw],a['context_end'])
li=list(a['locations']).index('US');levels=a['quantile_levels'];idx=lambda x:int(np.flatnonzero(np.isclose(levels,x))[0]);dates=a['target_dates'][:,0].astype('datetime64[D]');context=a['context_end'].astype('datetime64[D]')
fig,axes=plt.subplots(2,3,figsize=(15,9))
for k,name in enumerate(['Flu','COVID','RSV']):
 ax=axes[0,k]
 for data,color,label in [(a,'#64748b','Raw-input forecast'),(b,'#0284c7','Raw/full-history mixture')]:
  quant=data['quantiles'];ax.fill_between(dates,quant[idx(.05),:,0,k,li],quant[idx(.95),:,0,k,li],color=color,alpha=.12)
  ax.plot(dates,quant[idx(.5),:,0,k,li],color=color,label=label,linewidth=1.3)
 truth=np.where(a['mask'][:,0,k,li],a['truth'][:,0,k,li],np.nan);ax.plot(dates,truth,color='#111827',linewidth=1.4,label='Finalized label');ax.set_title(f'US {name} admissions: one-week-ahead forecast');ax.set_ylabel('Weekly admissions');ax.grid(alpha=.2)
 ax=axes[1,k]
 for data,color,label,style in [(raw,'#64748b','Archived current-week input','-'),(est,'#0284c7','Full correction endpoint','--'),(fold.score,'#111827','Finalized recent value','-')]:
  values=np.array([e['values'][-1,k,li] if e['available'][-1,k,li] else np.nan for e in data]);ax.plot(context,values,color=color,label=label,ls=style,linewidth=1.3)
 ax.set_title(f'US {name}: current-week history supplied to mixture');ax.set_ylabel('Weekly admissions');ax.grid(alpha=.2)
 for ax in axes[:,k]:ax.tick_params(axis='x',rotation=35,labelsize=8)
axes[0,0].legend(fontsize=8);axes[1,0].legend(fontsize=8)
fig.suptitle('Illustrative trajectories: fixed C1 with a no-covariate nonlinear nowcaster, seed42, evaluate2025–26',fontsize=12)
fig.text(.01,.01,'Preselected US/seed42 descriptive view of all eligible seasonal origins, not a frozen-support aggregate. Top bands: central90% predictive intervals from2048draws.\nC1: pathogen MLPs, distance sharing, no covariates; trained on unchanged finalized inputs/future labels in2022–23,2023–24,2024–25. Weights stay fixed.\nNowcaster: reported eight-week target paths, calendar/location, no covariates; same training trajectories, synthetic errors only2024–25, finalized recent labels.\nEvaluation uses archived Wednesday values under B2 availability/lags with explicit final proxies. Each mixture draw uses either the raw or fully corrected history.\nBottom blue line is the full-correction endpoint, not the mixture median. Final values shown only as evaluation references; no held-out labels enter fitting.',fontsize=8)
fig.tight_layout(rect=(0,.14,1,.95));fig.savefig('docs/experiments/nowcast-overnight-20261005/us-admission-correction-trajectories.png',dpi=170);plt.close(fig)
