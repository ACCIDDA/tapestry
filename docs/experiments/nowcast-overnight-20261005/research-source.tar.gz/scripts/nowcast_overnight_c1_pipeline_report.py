"""Same-corrector H100256 comparison: fixed versus retrained C1 forecasters."""
from pathlib import Path
import pandas as pd
from tapestry.experiment.planner import rank
from tapestry.model.scenario import Scenario
out=Path('docs/experiments/nowcast-overnight-20261005');parts=[]
for exp in ['nowcast-overnight-c1-pipeline-20261005','nowcast-overnight-c1-pipeline-replay-20261005']:
 root=Path('data/experiments')/exp;r=rank(root,allow_incomplete=True,make_plots=False)
 q=pd.read_csv(r/'season_composite_scores.csv');d=pd.read_csv(root/'design.csv').rename(columns={'scenario':'config_id'});q=q.merge(d,on='config_id',validate='many_to_one');q['experiment']=exp
 for recipe in q.config_id.unique():
  s=Scenario.from_string(recipe);idx=q.config_id.eq(recipe)
  if s.weekend_family=='two_stage':strength=s.correction_strength;operation='Retrained C1 on corrected synthetic histories'
  elif s.fixed_nowcaster=='raw':strength=0.;operation='Saved C1; raw archived histories'
  else:
   pipeline=pd.read_csv(Path('data/experiments/nowcast-overnight-c1-pipeline-20261005/design.csv'))
   source=pipeline[pipeline.run_id.map(lambda r:r in s.fixed_nowcaster)].iloc[0]
   strength=Scenario.from_string(source.scenario).correction_strength;operation='Saved C1; corrected archived histories'
  q.loc[idx,'correction_strength']=strength;q.loc[idx,'operation']=operation
 parts.append(q)
q=pd.concat(parts);q=q[q.geography.eq('all')];raw=q[q.operation.eq('Saved C1; raw archived histories')][['seed','season','combined','run_id']].rename(columns={'combined':'matched_raw','run_id':'control_run_id'});q=q.merge(raw,on=['seed','season'],validate='many_to_one');q['paired_change_percent']=100*(q.combined/q.matched_raw-1)
q['model']='C1 pathogen-specific MLP, distance sharing, no covariates; H100256 draws'
q['training_seasons']=q.season.map({'2024-2025':'2022-23,2023-24,2025-26','2025-2026':'2022-23,2023-24,2024-25'});q['error_donor_season']=q.season.map({'2024-2025':'2025-26','2025-2026':'2024-25'})
q['labels']='Finalized future t+1..t+4 for forecaster; finalized recent histories for nowcaster'
q['nowcaster']='Nonlinear reported eight-week trajectory/calendar/location, no covariates; full synthetic reporting errors; season-cross-fitted training histories; identical saved final corrector for fixed/retrained pair'
q['evaluation']='Archived Wednesday histories under B2 availability/lags; same final proxies; learned log correction at specified strength'
q.to_csv(out/'c1-pipeline-isolation-per-seed.csv',index=False)
s=q.groupby(['operation','correction_strength','season']).agg(seeds=('seed','nunique'),wis_ratio=('combined','mean'),paired_change_percent=('paired_change_percent','mean')).reset_index();s.to_csv(out/'c1-pipeline-isolation-summary.csv',index=False);print(s.to_string(index=False))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig,axes=plt.subplots(1,2,figsize=(13,6))
for ax,season in zip(axes,['2024-2025','2025-2026']):
 for (op,strength),g in q[q.season.eq(season)].groupby(['operation','correction_strength']):ax.plot(g.seed,g.combined,'o-',label=f'{op}; correction{strength:g}')
 ax.set_xticks([42,43,44]);ax.set_xlabel('Training seed');ax.set_ylabel('WIS / matched Hub WIS; lower is better');ax.set_title('Evaluate '+season);ax.legend(fontsize=7);ax.grid(alpha=.2)
fig.suptitle('Does C1 benefit from retraining behind the same nonlinear nowcaster?')
fig.text(.01,.01,'C1: pathogen MLPs, distance sharing, no covariates. Saved C1 trained on unchanged final inputs; retrained C1 on cross-fitted corrected synthetic inputs.\n2024–25: train2022–23/2023–24/2025–26, error donor2025–26. 2025–26: train2022–23/2023–24/2024–25, donor2024–25.\nFinal future/recent labels remain unchanged. Nowcaster: reported trajectory/calendar/location, no covariates. Identical saved corrector within each fixed/retrained pair.\nEvaluation: archived Wednesday numerical inputs under B2 lags/availability and explicit final proxies. All arms H100256 draws. Development-season comparison.',fontsize=8)
fig.tight_layout(rect=(0,.14,1,.94));fig.savefig(out/'c1-pipeline-isolation.png',dpi=170);plt.close(fig)
