"""Does the fixed-C1 correction gain depend on Kinsa in the nowcaster?"""
import argparse,json,subprocess,sys
from pathlib import Path
from dataclasses import replace
import pandas as pd
from tapestry.model.scenario import Scenario
p=argparse.ArgumentParser();p.add_argument('-e','--experiment',required=True);p.add_argument('--seeds',nargs='+',default=['42','43','44']);a=p.parse_args()
source=Path('data/experiments/nowcast-overnight-pair-support-20261005');design=pd.read_csv(source/'design.csv');settings=json.loads((source/'experiment.json').read_text())
base=Scenario.from_string(design[design.treatment.str.contains('include zero-error fallback cells') & design.treatment.str.endswith('strength 1')].iloc[0].scenario)
raw=Scenario.from_string(design[design.treatment.str.contains('CPU replay control')].iloc[0].scenario)
rows=[]
for cov in ['source','none']:
 s=replace(base,fixed_history_mode='raw_full_mixture',fixed_nowcaster_covariates=cov)
 name='Kinsa features' if cov=='source' else 'no covariate features'
 rows.append(dict(architecture='C1',treatment=f'Coherent raw/full nonlinear correction mixture; nowcaster with {name}',family='fixed_corrected',scenario=s.scenario_string,run_id=s.run_id))
s=replace(raw,fixed_history_mode='point');rows.append(dict(architecture='C1',treatment='Raw archived input histories; identical history-bank CPU control',family='fixed_corrected',scenario=s.scenario_string,run_id=s.run_id))
cmd=[sys.executable,'-m','tapestry.experiment.planner','plan','-e',a.experiment,'-s',*[r['scenario'] for r in rows],'--seeds',*a.seeds,'--device','cpu','--eval-members','256','--dataset',settings['dataset'],'--frozen',settings['frozen']]
subprocess.run(cmd,check=True);pd.DataFrame(rows).to_csv(Path('data/experiments')/a.experiment/'design.csv',index=False);print(' '.join(cmd))
