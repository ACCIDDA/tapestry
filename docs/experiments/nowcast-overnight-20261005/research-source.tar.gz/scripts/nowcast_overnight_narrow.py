"""Keep three-seed clean controls; defer unstarted replication of pilot treatments."""
import json
from pathlib import Path
from tapestry.experiment.dispatch import queue_lock
from tapestry.experiment.planner import read_jobs,write_jobs,save
from tapestry.model.scenario import Scenario
p=Path('data/experiments/nowcast-overnight-joint-pilot-20261005')
removed=[]
with queue_lock(p):
    jobs=read_jobs(p);state=json.loads((p/'dispatch.json').read_text())
    for job in jobs:
        s=Scenario.from_string(job['scenario'])
        if s.reporting_probability==0 or (p/f'confirmed-{s.run_id}.json').exists():continue
        entry=state['tasks'][str(job['task'])]
        keep=[]
        for seed in job['seeds']:
            if seed==42 or str(seed) in entry['active'] or entry['seeds'].get(str(seed))=='complete':
                keep.append(seed)
            else:
                entry['seeds'].pop(str(seed),None)
                removed.append(dict(task=job['task'],run_id=s.run_id,seed=seed))
        job['seeds']=keep
    write_jobs(p,jobs);save(p/'dispatch.json',state);save(p/'deferred_replication.json',json.loads((p/'deferred_replication.json').read_text())+removed if (p/'deferred_replication.json').exists() else removed)
print(f'Deferred {len(removed)} unstarted seed fits; running fits and three-seed clean controls preserved')
