"""Describe archived input revisions; no model fitting or forecast scoring."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from tapestry.dataset import cv
from tapestry.dataset.build import load
from tapestry.model.scenario import Scenario
from tapestry.experiment.weekend import scheduled_reports
p=Path('docs/experiments/nowcast-overnight-20261005');p.mkdir(parents=True,exist_ok=True)
settings=json.loads(Path('data/experiments/b-2-t0/experiment.json').read_text())
panel=load(settings['dataset']);rows=[]
s=Scenario(input_mode='scheduled_final',evaluation_seasons='recent_two')
for held in s.scored_seasons:
    score=cv.fold(panel,s,held).score
    for age in range(8):
        for k,name in enumerate(panel['target_names']):
            for geography in ('states_dc','US'):
                logs=[];ab=[];zero=[];proxies=[]
                for e in score:
                    if cv.season(e['context_dates'][-1-age])!=held:continue
                    r,_=scheduled_reports(e,panel,[])
                    loc=np.array([x=='US' for x in e['locations']])
                    if geography=='states_dc':loc=~loc
                    ok=e['available'][-1-age,k]&loc
                    final=e['values'][-1-age,k,ok];reported=r['values'][-1-age,k,ok]
                    wi=np.searchsorted(panel['issuance_dates'].astype(str),r['issuance'])
                    ti=np.searchsorted(panel['dates'].astype(str),e['context_dates'][-1-age])
                    proxies.extend(~np.isfinite(panel['asof_targets'][wi,ti,:,k][ok]))
                    floor=max(1. if k<3 else .0001,float(np.nanmax(final))*.05) if len(final) else 1.
                    logs.extend(np.log((reported+floor)/(final+floor)))
                    ab.extend(abs(reported-final));zero.extend(reported==final)
                if logs:rows.append(dict(season=held,age=age,target=name,geography=geography,cells=len(logs),logratio_median=float(np.median(logs)),logratio_q10=float(np.quantile(logs,.1)),logratio_q90=float(np.quantile(logs,.9)),absolute_error_mean=float(np.mean(ab)),unchanged_fraction=float(np.mean(zero)),final_proxy_fraction=float(np.mean(proxies))))
pd.DataFrame(rows).to_csv(p/'archived-target-input-audit.csv',index=False)
print(pd.DataFrame(rows).query('age == 0').to_string(index=False))
