"""Native-unit nowcaster diagnostics alongside the shared forecasting score."""
import csv
import numpy as np
from tapestry.dataset.cv import season

def correction_diagnostics(truth, raw, corrected, weeks, held_out, output):
    rows=[]
    for age in range(weeks):
        for k in range(6):
            for geography in ('states_dc','US'):
                loc=np.array([x=='US' for x in truth[0]['locations']])
                if geography=='states_dc':loc=~loc
                before=[];after=[]
                for t,r,c in zip(truth,raw,corrected):
                    if season(t['context_dates'][-1-age]) != held_out:continue
                    ok=t['available'][-1-age,k]&r['available'][-1-age,k]&loc
                    before.extend(abs(r['values'][-1-age,k,ok]-t['values'][-1-age,k,ok]))
                    after.extend(abs(c['values'][-1-age,k,ok]-t['values'][-1-age,k,ok]))
                if before:rows.append(dict(age=age,channel=k,geography=geography,cells=len(before),raw_mae=float(np.mean(before)),corrected_mae=float(np.mean(after))))
    with (output/'nowcast_diagnostics.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def evaluate_fixed(scenario, seed, held_out, members, device, output, dataset):
    """Change only evaluation inputs of a saved clean-input forecast model."""
    import torch
    from pathlib import Path
    from tapestry.model.scenario import Scenario
    from tapestry.model.network import load_model,checkpoint
    from tapestry.dataset import cv
    from tapestry.dataset.build import load,covariate_names_for
    from .weekend import scheduled_reports
    from .training import evaluate
    from .provenance import sha256,save
    fp=Path(scenario.fixed_forecaster.format(seed=seed,season=held_out))
    npth=Path(scenario.fixed_nowcaster.format(seed=seed,season=held_out)) if scenario.fixed_nowcaster!='raw' else None
    saved=torch.load(fp,map_location='cpu',weights_only=False);original=saved['metadata']
    source=Scenario.from_string(original['scenario'])
    if original['seed']!=seed or original['held_out_season']!=held_out or original['dataset_sha256']!=sha256(dataset):
        raise ValueError('Fixed forecast checkpoint differs in seed, season, or dataset')
    if source.weekend_family!='direct' or source.reporting_probability!=0:
        raise ValueError('Expected a clean-input-trained direct forecaster')
    for name in ['fit_partition','spatial','covariate_set','lookback','mask_rate']:
        if getattr(source,name)!=getattr(scenario,name):raise ValueError(f'Architecture mismatch: {name}')
    corrector=torch.load(npth,map_location='cpu',weights_only=False)['final'] if npth else None
    permitted={'2022-2023','2023-2024','2024-2025','2025-2026'}-{held_out}
    if corrector and set(corrector.training_seasons)!=permitted:raise ValueError('Nowcaster trajectory seasons differ from permitted training split')
    panel=load(dataset);fold=cv.fold(panel,source,held_out)
    raw=[scheduled_reports(e,panel,list(covariate_names_for(source.covariate_set)))[0] for e in fold.score]
    correction_scenario=None;corrector_error_record=None;uncertainty_record=None
    if corrector:
        import pandas as pd
        design=pd.read_csv(npth.parents[4]/'design.csv')
        selected=design[design.run_id.eq(npth.parents[3].name)]
        if len(selected)!=1:raise ValueError('Nowcaster source recipe is ambiguous')
        import json
        source_manifest=npth.parent/'manifest.json'
        source_metadata=json.loads(source_manifest.read_text()) if source_manifest.exists() else {}
        correction_scenario=Scenario.from_string(source_metadata.get('corrector_source_scenario') or selected.iloc[0].scenario)
        correction_fold=cv.fold(panel,correction_scenario,held_out)
        correction_truth=correction_fold.score
        template=corrector
        if scenario.fixed_refit_nowcaster:
            from dataclasses import replace
            correction_scenario=replace(correction_scenario,correction_observed_pairs_only=scenario.correction_observed_pairs_only)
            if scenario.fixed_nowcaster_covariates=='none':
                correction_scenario=replace(correction_scenario,covariate_set='')
                correction_fold=cv.fold(panel,correction_scenario,held_out)
                correction_truth=correction_fold.score
            from .weekend import fit_correctors
            from tapestry.dataset.reporting_error import ReportingErrors
            roles=cv.week_roles(panel['dates'],correction_scenario,held_out)
            errors=ReportingErrors(panel,correction_scenario,held_out,np.isin(roles,['fit','validation']))
            cross,corrector=fit_correctors(correction_fold.train,errors,correction_scenario,seed)
            corrector_error_record=errors.metadata
            if set(corrector.training_seasons)!=permitted:raise ValueError('Refitted nowcaster leaked a trajectory season')
            Path(output).mkdir(parents=True,exist_ok=True)
            # Save the final estimator after setting its applied correction strength below.
        by_date={e['context_dates'][-1]:e for e in correction_truth}
        correction_raw=[scheduled_reports(by_date[e['context_dates'][-1]],panel,list(covariate_names_for(correction_scenario.covariate_set)))[0] for e in fold.score]
        for x,y in zip(raw,correction_raw):
            for key in ['values','available','context_dates','locations']:
                np.testing.assert_array_equal(x[key],y[key],err_msg=f'Nowcaster/forecaster input mismatch: {key}')
        if scenario.fixed_refit_nowcaster and seed==42 and not scenario.correction_observed_pairs_only and scenario.fixed_nowcaster_covariates=='source':
            old=template.apply_batch(correction_raw[:2]) if hasattr(template,'apply_batch') else [template.apply(e) for e in correction_raw[:2]]
            new=corrector.apply_batch(correction_raw[:2]) if hasattr(corrector,'apply_batch') else [corrector.apply(e) for e in correction_raw[:2]]
            for x,y in zip(old,new):np.testing.assert_allclose(x['values'],y['values'],rtol=1e-6,atol=1e-6,err_msg='Refit differs from seed42 source nowcaster')
        if scenario.fixed_refit_nowcaster:
            corrector.strength=scenario.correction_strength
            torch.save(dict(final=corrector),Path(output)/'nowcast_correctors.pt')
        estimates=corrector.apply_batch(correction_raw) if hasattr(corrector,'apply_batch') else [corrector.apply(e) for e in correction_raw]
        # Only target histories change. The forecast model keeps its own covariates.
        corrected=[dict(x,values=y['values']) for x,y in zip(raw,estimates)]
    else:corrected=raw
    if scenario.fixed_correction_channels=='admissions':
        corrected=[dict(y,values=np.concatenate((y['values'][:,:3],x['values'][:,3:]),axis=1)) for x,y in zip(raw,corrected)]
    for x,y in zip(raw,corrected):
        for key in ['target_values','target_available','target_dates','available']:
            np.testing.assert_array_equal(x[key],y[key],err_msg=f'Correction changed {key}')
    if scenario.fixed_history_mode=='crossfit_residual':
        corrected,uncertainty_record=crossfit_residual_histories(correction_fold.train,errors,cross,corrector,correction_raw,corrected,members,seed,scenario.fixed_uncertainty_strength,scenario.fixed_correction_channels)
    elif scenario.fixed_history_mode!='none':
        if scenario.fixed_history_mode=='raw_full_mixture' and (corrector is None or corrector.strength!=1 or members%2):
            raise ValueError('Raw/full mixture needs a full-strength corrector and even member count')
        for x,y in zip(raw,corrected):
            bank=np.broadcast_to(y['values'],(members,*y['values'].shape)).copy()
            if scenario.fixed_history_mode=='raw_full_mixture':
                # One global hypothesis per draw preserves cross-target/location/week coherence.
                # Alternate hypotheses to balance every sampling chunk; this is a sensitivity
                # distribution, not an empirically calibrated posterior.
                bank[::2]=x['values']
                np.testing.assert_array_equal(bank[0],x['values'])
                np.testing.assert_array_equal(bank[1],y['values'])
            y['history_samples']=bank
    out=Path(output);out.mkdir(parents=True,exist_ok=True)
    model=load_model(saved).to(device)
    metadata=dict(original,scenario=scenario.scenario_string,run_id=scenario.run_id,
        operation='No forecaster retraining: saved clean-input forecaster receives '+('learned-corrected' if corrector else 'raw')+' archived evaluation inputs',
        corrector_error_source_season=('2024-2025' if held_out=='2025-2026' else '2025-2026') if corrector else None,
        original_forecaster_scenario=source.scenario_string,
        source_forecaster=str(fp),source_forecaster_sha256=sha256(fp),source_nowcaster=str(npth) if npth else None,source_nowcaster_sha256=sha256(npth) if npth else None,
        nowcaster_covariates=scenario.fixed_nowcaster_covariates,correction_channels=scenario.fixed_correction_channels,history_mode=scenario.fixed_history_mode,crossfit_uncertainty=uncertainty_record,history_interpretation='Equal-weight coherent raw/full correction hypotheses; uncalibrated sensitivity' if scenario.fixed_history_mode=='raw_full_mixture' else ('Cross-fitted synthetic residual bootstrap' if scenario.fixed_history_mode=='crossfit_residual' else 'Point history'),
        correction=corrector.record() if corrector else None,corrector_source_scenario=correction_scenario.scenario_string if correction_scenario else None,nowcaster_refitted=scenario.fixed_refit_nowcaster,nowcaster_fit_seed=seed if scenario.fixed_refit_nowcaster else None,nowcaster_reporting_errors=corrector_error_record,eval_members=members)
    torch.save(checkpoint(model,metadata),out/'model.pt');save(out/'manifest.json',metadata)
    if corrector:correction_diagnostics(fold.score,raw,corrected,corrector.weeks,held_out,out)
    torch.manual_seed(seed+1000)
    return evaluate(model,corrected,members,device,out)


def crossfit_residual_histories(train,errors,cross,corrector,reported,centers,members,seed,strength,channels='all'):
    """Bootstrap intact out-of-season synthetic revision residual trajectories.

    This uncertainty is learned from permitted training data, not calibrated on
    evaluation labels. Median centering preserves the chosen point correction.
    """
    from tapestry.dataset.cv import season
    rng=np.random.default_rng(seed+420000)
    residuals=[];donor_seasons=[]
    indices=np.arange(-1,-corrector.weeks-1,-1)
    for label,model in cross.items():
        if label in model.training_seasons:raise ValueError('Residual estimator saw its trajectory season')
        truths=[e for e in train if season(e['context_dates'][-1])==label for _ in range(2)]
        raw=[errors.draw(e,rng) for e in truths]
        estimates=model.apply_batch(raw)
        for x,y,t in zip(raw,estimates,truths):
            floor=np.stack([model.design(x,k)[1] for k in range(6)])
            ok=x['available'][indices]&t['available'][indices]
            # Context may cross a season boundary: retain only this held-out
            # trajectory season's labels, never in-season fitted residuals.
            ok &= np.array([season(x['context_dates'][i])==label for i in indices])[:,None,None]
            z=np.log((t['values'][indices]+floor)/(y['values'][indices]+floor))
            residuals.append(np.where(ok,np.clip(z,-np.log(4),np.log(4)),np.nan))
            donor_seasons.append(label)
    bank=np.stack(residuals);support=np.isfinite(bank)
    counts={s:donor_seasons.count(s) for s in set(donor_seasons)}
    weights=np.array([1./counts[s] for s in donor_seasons]);weights/=weights.sum()
    order=np.argsort(np.where(support,bank,np.inf),axis=0)
    sorted_bank=np.take_along_axis(bank,order,axis=0)
    cell_weights=np.where(support,weights[:,None,None,None],0.)
    cumulative=np.cumsum(np.take_along_axis(cell_weights,order,axis=0),axis=0)
    median_index=(cumulative<.5*cumulative[-1]).sum(0).clip(0,len(bank)-1)
    median=np.take_along_axis(sorted_bank,median_index[None],axis=0)[0]
    noise=np.nan_to_num(np.where(support,bank-median,0.))
    out=[]
    for x,c in zip(reported,centers):
        issue=int(np.datetime64(x['context_dates'][-1],'D').astype(int))
        chosen=np.random.default_rng(seed+430000+issue).choice(len(bank),size=members,p=weights)
        histories=np.broadcast_to(c['values'],(members,*c['values'].shape)).copy()
        floor=np.stack([corrector.design(x,k)[1] for k in range(6)])
        values=np.maximum(0,(c['values'][indices]+floor)*np.exp(strength*noise[chosen])-floor)
        values[:,:,3:]=np.minimum(1,values[:,:,3:])
        if channels=='admissions':values[:,:,3:]=c['values'][indices,3:]
        histories[:,indices]=np.where(x['available'][indices],values,0.)
        # Earlier history, availability and finalized future labels are unchanged.
        np.testing.assert_array_equal(histories[:,:-corrector.weeks],np.broadcast_to(c['values'][:-corrector.weeks],histories[:,:-corrector.weeks].shape))
        out.append(dict(c,history_samples=histories))
    record=dict(method='Intact cross-fitted synthetic log-revision residual bootstrap; cellwise median centered; seasons sampled equally',
        donor_trajectory_seasons=sorted(counts),donors=len(bank),supported_fraction=float(support.mean()),
        noise_strength=strength,point_correction_strength=corrector.strength,channels=channels,
        labels='Final recent histories from permitted training seasons only; each residual predictor excluded its trajectory season',
        calibration='Synthetic training residual distribution; no evaluation-season fitting or posterior-calibration claim')
    return out,record
