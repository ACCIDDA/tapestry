"""Nonlinear residual nowcaster trained only on permitted synthetic trajectories.

The predictor sees reported histories, their masks, annual phase, and optional
reported covariates. Finalized histories are labels, never predictors. Tree
capacity is deliberately small; entire trajectory seasons are cross-fitted by
the weekend orchestrator before this nowcaster supplies forecaster inputs.
"""
import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor
from tapestry.dataset.cv import season
from tapestry.dataset.episodes import calendar
from tapestry.model.revision_regression import RevisionRegression

class TrajectoryNowcaster(RevisionRegression):
    def design(self,e,channel):
        values=e['values'].astype(float); valid=e['available']
        units=np.array([1.,1.,1.,.0001,.0001,.0001])[:,None]
        scale=np.maximum(np.max(np.where(valid,values,0),axis=0),units)
        floor=np.maximum(.05*scale,units)
        log=np.log((values+floor)/(scale+floor))
        log=np.where(valid,log,np.nan)
        l=values.shape[-1]
        # A full recent path preserves direction, acceleration and isolated dips.
        own=log[-8:,channel].T
        ownmask=valid[-8:,channel].T.astype(float)
        cross=[]
        for a,b in ((-2,None),(-4,-2),(-8,-4)):
            z=log[a:b];ok=valid[a:b]
            cross.append(np.divide(np.nansum(z,axis=0),ok.sum(0),out=np.zeros_like(scale),where=ok.sum(0)>0).T)
        cal=np.broadcast_to(calendar([e['context_dates'][-1]])[0],(l,3))
        pieces=[own,ownmask,*cross,cal,np.eye(l)]
        if 'covariates' in e:
            cov=e['covariates']; cv=cov[...,0,:]; ca=cov[...,1,:].astype(bool)
            for a,b in ((-2,None),(-6,-2)):
                x=np.divide(np.where(ca[a:b],cv[a:b],0).sum(0),ca[a:b].sum(0),out=np.zeros_like(cv[0]),where=ca[a:b].sum(0)>0)
                pieces.append(np.sign(x.T)*np.log1p(np.abs(x.T)))
        shared=np.concatenate(pieces,axis=1)
        # Keep age explicit, with one common estimator to share phase relationships.
        rows=[np.column_stack((np.full(l,age),shared)) for age in range(self.weeks)]
        return np.stack(rows),floor[channel]

    def fit(self,examples):
        self.models=[];self.training_cells=[]
        seasons=[season(t['context_dates'][-1]) for _,t in examples]
        self.training_seasons=sorted(set(seasons))
        counts={s:seasons.count(s) for s in set(seasons)}
        indices=np.arange(-1,-self.weeks-1,-1)
        for k in range(6):
            xs=[];ys=[];ws=[]
            for (reported,truth),s in zip(examples,seasons):
                x,floor=self.design(reported,k)
                ok=reported['available'][indices,k]&truth['available'][indices,k]
                y=np.log((truth['values'][indices,k]+floor)/(reported['values'][indices,k]+floor))
                xs.append(x[ok]);ys.append(y[ok]);ws.append(np.full(ok.sum(),1./counts[s]))
            x=np.concatenate(xs);y=np.concatenate(ys);w=np.concatenate(ws)
            self.training_cells.append(len(y))
            w*=len(w)/w.sum()
            model=HistGradientBoostingRegressor(max_iter=100,max_leaf_nodes=7,min_samples_leaf=100,
                l2_regularization=self.penalty,learning_rate=.05,early_stopping=False,random_state=0)
            model.fit(x,y,sample_weight=w);self.models.append(model)
        return self

    def apply_batch(self,episodes):
        values=[e['values'].copy() for e in episodes]
        indices=np.arange(-1,-self.weeks-1,-1)
        for k,model in enumerate(self.models):
            designs=[self.design(e,k) for e in episodes]
            matrices=[x.reshape(-1,x.shape[-1]) for x,_ in designs]
            predictions=model.predict(np.concatenate(matrices))
            pos=0
            for v,(x,floor),matrix in zip(values,designs,matrices):
                correction=np.clip(predictions[pos:pos+len(matrix)].reshape(x.shape[:2]),-np.log(4),np.log(4))*self.strength
                pos+=len(matrix)
                v[indices,k]=np.maximum(0,(v[indices,k]+floor)*np.exp(correction)-floor)
        out=[]
        for e,v in zip(episodes,values):
            v[:,3:]=np.minimum(1,v[:,3:])
            out.append(dict(e,values=np.where(e['available'],v,0).astype(np.float32),known_final=np.zeros_like(e['available'])))
        return out

    def apply(self,e):
        return self.apply_batch([e])[0]

    def record(self):
        return dict(model='Histogram gradient boosting;100trees;7leaves;minleaf100',weeks=self.weeks,
            penalty=self.penalty,strength=self.strength,features=self.features,training_seasons=self.training_seasons,
            observed_donor_pairs_only=getattr(self,'observed_donor_pairs_only',False),training_cells=getattr(self,'training_cells',None),
            features_description='Reported eight-week own trajectory, six-channel multiscale levels, availability, annual phase, location indicators, optional reported covariates; no final predictors')
